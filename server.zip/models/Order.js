const mongoose = require('mongoose');

const OrderItemSchema = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  name: { type: String, default: '' },
  price: { type: Number, default: 0 },
  quantity: { type: Number, required: true, min: 1 },
  packed: { type: Boolean, default: false },
  // How many units were ACTUALLY put in the box. `packed` alone is a boolean and
  // cannot carry "7 of the 10 you ordered" — the warehouse is allowed to hand over
  // less than ordered, but the difference must survive into the order, otherwise
  // the seller is billed and shown a full delivery that never happened.
  // null = not processed yet. Equal to `quantity` on a normal full pick.
  packedQuantity: { type: Number, default: null },
  // Why less was delivered than ordered. Distinct from `cancelled` (nothing at
  // all arrives) — here part of the position did arrive.
  //   short_pick — the picker found fewer units on the shelf than ordered
  shortfallReason: { type: String, enum: ['short_pick', null], default: null },
  // Who closed this position and when — the shortfall has to be attributable.
  packedBy:     { type: String, default: '' },
  packedByName: { type: String, default: '' },
  packedAt:     { type: Date,   default: null },
  // WAREHOUSE-ONLY: the product ran out / was archived mid-picking, so this
  // position will not be delivered (services/archiveProduct.js). The seller's
  // app renders it as the rose «Закінчився» badge + the «Є товари, що не
  // приїдуть» chip on the order. A buyer who un-picks a product does NOT set
  // this — that position is spliced out of `items` entirely (routes/orders.js
  // /remove-item and /upsert-item qty=0), with the audit trail left in
  // `history.item_removed`. Do not reuse this flag for buyer-side removal:
  // it tells the seller the warehouse ran out of something they never ordered.
  cancelled: { type: Boolean, default: false },
  // STRICT late-order handling: set when an order reaches a session whose picking
  // has already started and this product no longer has an OPEN (pending) picking
  // task to ride along on — the warehouse walked past it / it was never in the
  // pick plan, and in strict mode nobody goes back. Distinct from `cancelled`
  // (out-of-stock / archived) and from `packed`. A skipped item is terminal for
  // this session: excluded from picking, totals and "left to pick" counts, but
  // NOT delivered. See services/lateOrderReconcile.js.
  skipped: { type: Boolean, default: false },
  // ORDER-LEVEL retirement: the whole order left this delivery cycle (expired).
  // Distinct from `cancelled` (warehouse/OOS) and `skipped` (strict late-order).
  // Keeps historical ordered-vs-delivered analytics explicit instead of leaving
  // forever-open rows hidden behind Order.status='expired'.
  voided: { type: Boolean, default: false },
  voidReason: { type: String, default: '' },
  voidedAt: { type: Date, default: null },
});

const BuyerSnapshotSchema = new mongoose.Schema({
  shopId: { type: mongoose.Schema.Types.ObjectId, ref: 'Shop', default: null },
  shopName: { type: String, default: '' },
  shopCity: { type: String, default: '' },
  shopAddress: { type: String, default: '' },
  deliveryGroupId: { type: String, default: '' },
}, { _id: false });

const OrderHistoryEntrySchema = new mongoose.Schema({
  at: { type: Date, default: Date.now },
  by: { type: String, default: 'system' },
  byName: { type: String, default: '' },
  byRole: { type: String, default: 'system' },
  action: { type: String, required: true },
  meta: { type: mongoose.Schema.Types.Mixed, default: {} },
}, { _id: false });

const OrderSchema = new mongoose.Schema(
  {
    buyerTelegramId: { type: String, required: true },
    shopId: { type: mongoose.Schema.Types.ObjectId, ref: 'Shop', default: null },
    items: { type: [OrderItemSchema], required: true },
    // 'confirmed' (some items packed, rest OOS-cancelled) and 'cancelled' (all
    // items OOS-cancelled) are written by services/archiveProduct.js via
    // order.save() — they MUST be in the enum, else the OOS path throws a
    // validation error mid-transaction (product not archived, task not completed → 500).
    status: { type: String, enum: ['new', 'in_progress', 'confirmed', 'fulfilled', 'cancelled', 'expired'], default: 'new' },
    totalPrice: { type: Number, default: 0 },
    orderType: { type: String, enum: ['manual', 'direct_allocation'], default: 'manual' },
    receiptId: { type: mongoose.Schema.Types.ObjectId, ref: 'Receipt', default: null },
    emojiType: { type: String, default: '' },
    shippingAddress: { type: String, default: '' },
    contactInfo: { type: String, default: '' },
    idempotencyKey: { type: String },
    orderingSessionId: { type: String, default: '' },
    buyerSnapshot: { type: BuyerSnapshotSchema, default: null },
    orderNumber: { type: Number, default: null },
    history: { type: [OrderHistoryEntrySchema], default: [] },
  },
  { timestamps: true }
);

OrderSchema.index({ idempotencyKey: 1 }, { unique: true, sparse: true });
OrderSchema.index({ orderingSessionId: 1 });
OrderSchema.index({ orderNumber: 1 }, { unique: true, sparse: true });

// At most ONE active (new/in_progress) order per (buyer, shop, ordering session).
// This is the DB-level backstop for the duplicate-order race: two concurrent
// POST /orders with DIFFERENT idempotency keys each find no existing active order
// and each insert one. A MongoDB transaction does NOT prevent that (two distinct
// inserts never write-conflict); the Redis placement lock does, but it degrades to
// a per-process mutex when REDIS_URL is unset — so on a multi-worker deploy without
// Redis the lock is a no-op across workers and duplicates slip through. This unique
// partial index makes the invariant hold regardless of Redis: the second insert
// throws E11000, which the placement handler catches and resolves to the existing
// order (see routes/orders.js). The partialFilterExpression scopes uniqueness to
// fully-keyed active orders only, so parked orders (shopId:null), terminal orders,
// and the no-delivery-group fallback path (empty orderingSessionId) are unaffected.
OrderSchema.index(
  { buyerTelegramId: 1, shopId: 1, orderingSessionId: 1 },
  {
    unique: true,
    name: 'one_active_order_per_buyer_shop_session',
    partialFilterExpression: {
      status: { $in: ['new', 'in_progress'] },
      shopId: { $type: 'objectId' },
      orderingSessionId: { $gt: '' },
    },
  },
);

function normalizeOrderItems(items = []) {
  const grouped = new Map();
  for (const item of items) {
    const productId = String(item.productId || '');
    if (!productId) continue;

    const existing = grouped.get(productId);
    if (!existing) {
      grouped.set(productId, {
        productId: item.productId,
        name: item.name || '',
        price: item.price || 0,
        quantity: Number(item.quantity || 0),
        packed: Boolean(item.packed),
        cancelled: Boolean(item.cancelled),
        skipped: Boolean(item.skipped),
        voided: Boolean(item.voided),
        voidReason: item.voidReason || '',
        voidedAt: item.voidedAt || null,
        // Fulfilment fields must be carried through: this normaliser REPLACES
        // `items` wholesale, so anything omitted here is silently erased from a
        // merged order — which would quietly destroy the ordered-vs-delivered
        // record the warehouse just wrote.
        packedQuantity: item.packedQuantity ?? null,
        shortfallReason: item.shortfallReason || null,
        packedBy: item.packedBy || '',
        packedByName: item.packedByName || '',
        packedAt: item.packedAt || null,
      });
    } else {
      existing.quantity += Number(item.quantity || 0);
      existing.packed = existing.packed || Boolean(item.packed);
      existing.cancelled = existing.cancelled || Boolean(item.cancelled);
      existing.skipped = existing.skipped || Boolean(item.skipped);
      existing.voided = existing.voided || Boolean(item.voided);
      existing.voidReason = existing.voidReason || item.voidReason || '';
      existing.voidedAt = existing.voidedAt || item.voidedAt || null;
      // Delivered units add up the same way ordered units do; null + null stays
      // null so an untouched merge is not turned into a "0 delivered" record.
      if (item.packedQuantity != null || existing.packedQuantity != null) {
        existing.packedQuantity = Number(existing.packedQuantity || 0) + Number(item.packedQuantity || 0);
      }
      existing.shortfallReason = existing.shortfallReason || item.shortfallReason || null;
      existing.packedBy     = existing.packedBy     || item.packedBy     || '';
      existing.packedByName = existing.packedByName || item.packedByName || '';
      existing.packedAt     = existing.packedAt     || item.packedAt     || null;
    }
  }
  return Array.from(grouped.values());
}

OrderSchema.pre('save', function normalizeItemsOnSave(next) {
  if (!Array.isArray(this.items) || this.items.length < 2) return next();

  const normalizedItems = normalizeOrderItems(this.items);
  if (normalizedItems.length === this.items.length) return next();

  this.items = normalizedItems;
  this.totalPrice = require('../utils/money').roundMoney(
    this.items.reduce((sum, item) => sum + (Number(item.price || 0) * Number(item.quantity || 0)), 0),
  );
  next();
});

OrderSchema.statics.normalizeItems = normalizeOrderItems;

module.exports = mongoose.model('Order', OrderSchema);
