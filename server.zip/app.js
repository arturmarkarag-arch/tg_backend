const express = require('express');
const cors = require('cors');
const path = require('path');
const productsRouter = require('./routes/products');
const usersRouter = require('./routes/users');
const warehouseRouter = require('./routes/warehouse');
const ordersRouter = require('./routes/orders');
const deliveryGroupsRouter = require('./routes/deliveryGroups');
const { router: archiveRouter } = require('./routes/archive');
const blocksRouter = require('./routes/blocks');
const telegramV1Router = require('./routes/v1/telegram');
const authV1Router = require('./routes/v1/auth');
const adminRouter = require('./routes/admin');
const searchProductsRouter = require('./routes/searchProducts');
const { getBotStatus, getWebhookConfig, handleWebhookUpdate } = require('./telegramBot');
const { verifyOpenAIConnection } = require('./openaiClient');
const { verifyGeminiConnection } = require('./geminiClient');
const receiptsRouter = require('./routes/receipts');
const pickingRouter = require('./routes/picking');
const shopsRouter = require('./routes/shops');
const shopTransferRouter  = require('./routes/shopTransfer');
const shopProductsRouter  = require('./routes/shopProducts');
const visionSearchRouter  = require('./routes/visionSearch');
const productFeedbackRouter = require('./routes/productFeedback');

// The warehouse test harness (destructive: cleanup/seed/reset of real
// collections) must NEVER be reachable in production. It is loaded and mounted
// only outside production. Even then it is NOT a public path — it requires the
// normal telegramAuth (admin) middleware as defense-in-depth.
const ENABLE_TEST_API = process.env.NODE_ENV !== 'production';

const { expressCorsOptions } = require('./utils/corsOptions');

const app = express();
app.use(cors(expressCorsOptions));
app.use(express.json());
app.use('/uploads', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  next();
}, express.static(path.join(__dirname, 'uploads')));
if (ENABLE_TEST_API) {
  app.use('/warehouse-test', express.static(path.join(__dirname, '../Тести Е2Е/test-warehouse')));
}

// Telegram webhook delivery. Mounted BEFORE the API auth gate: Telegram posts
// server-to-server with no telegram initData / JWT, so the auth here is the
// unguessable token-derived path + the secret-token header. Body is already
// JSON-parsed by express.json() above. Always mounted (dormant in polling mode,
// since no webhook URL is registered then) — the path is unguessable regardless.
{
  const wh = getWebhookConfig();
  app.post(wh.path, (req, res) => {
    if (wh.secretToken && req.get('x-telegram-bot-api-secret-token') !== wh.secretToken) {
      return res.sendStatus(403);
    }
    // Ack immediately, then process — never make Telegram wait on (or retry over)
    // our handler work. processUpdate emits synchronously; handlers run detached.
    res.sendStatus(200);
    try { handleWebhookUpdate(req.body); } catch (err) {
      console.error('[webhook] processUpdate failed:', err?.message);
    }
  });
}

const { telegramAuth } = require('./middleware/telegramAuth');

const publicApiPaths = [
  /^\/api\/v1\/auth(\/.*)?$/,
  /^\/api\/search-products(\/.*)?$/,
  /^\/api\/v1\/products\/report-missing$/,
  /^\/api\/v1\/telegram\/validate$/,
  /^\/api\/v1\/telegram\/register-request$/,
  // Self-service invite for a group member who opened the mini-app without a
  // ?regToken. Necessarily pre-registration (the caller has no User row yet),
  // so it cannot sit behind telegramAuth. It authenticates the caller itself
  // via signed initData and re-checks group membership live before minting.
  /^\/api\/v1\/telegram\/registration-invite$/,
  /^\/api\/v1\/telegram\/me$/,
  /^\/api\/delivery-groups\/summary$/,
  /^\/api\/shops\/cities$/,
  // Minimal, seller-PII-free shop list for the registration screen. The full
  // GET /api/shops (with seller data) now requires auth and is staff-only.
  /^\/api\/shops\/registry$/,
  /^\/api\/shop-products\/barcode\/.+$/,
  /^\/api\/health$/,
  /^\/api\/bot-status$/,
  /^\/api\/openai-status$/,
  /^\/api\/gemini-status$/,
];

// The test harness UI calls warehouse-test without auth. This is acceptable
// ONLY because the entire route is unmounted in production (ENABLE_TEST_API).
// In production this entry never exists, so it cannot widen the attack surface.
if (ENABLE_TEST_API) {
  publicApiPaths.push(/^\/api\/warehouse-test(\/.*)?$/);
}

function requireAuthForApi(req, res, next) {
  if (!req.path.startsWith('/api')) return next();
  const isPublic = publicApiPaths.some((pattern) => pattern.test(req.path));
  if (isPublic) return next();
  return telegramAuth(req, res, next);
}

app.use(requireAuthForApi);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', environment: process.env.NODE_ENV || 'development' });
});

app.get('/api/bot-status', (req, res) => {
  res.json(getBotStatus());
});

app.get('/api/openai-status', async (req, res) => {
  try {
    const result = await verifyOpenAIConnection();
    res.json(result);
  } catch (error) {
    const { t } = require('./utils/errors');
    res.status(500).json({
      status: 'error',
      error: 'openai_connection_failed',
      message: t('openai_connection_failed', { reason: error?.message }),
    });
  }
});

app.get('/api/gemini-status', async (req, res) => {
  try {
    const result = await verifyGeminiConnection();
    res.json(result);
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'gemini_connection_failed',
      message: error?.message || 'Gemini connection failed',
    });
  }
});

app.use('/api/products', productsRouter);
app.use('/api/v1/products', productsRouter);
app.use('/api/users', usersRouter);
app.use('/api/warehouse', warehouseRouter);
app.use('/api/v1/orders', ordersRouter);
app.use('/api/delivery-groups', deliveryGroupsRouter);
app.use('/api/archive', archiveRouter);
app.use('/api/blocks', blocksRouter);
app.use('/api/search-products', searchProductsRouter);
app.use('/api/receipts', receiptsRouter);
app.use('/api/picking', pickingRouter);
app.use('/api/admin', adminRouter);
app.use('/api/shops', shopsRouter);
app.use('/api/shop-transfer', shopTransferRouter);
app.use('/api/shop-products',  shopProductsRouter);
app.use('/api/vision-search', visionSearchRouter);
app.use('/api/product-feedback', productFeedbackRouter);
app.use('/api/v1/telegram', telegramV1Router);
app.use('/api/v1/auth', authV1Router);
if (ENABLE_TEST_API) {
  // eslint-disable-next-line global-require
  app.use('/api/warehouse-test', require('./routes/warehouseTest'));
}

// Centralised error handler — converts AppError (and known Mongoose errors)
// into a consistent JSON envelope { error: <code>, message: <ukrainian text>, ... }.
// All routes that throw `appError(...)` (utils/errors.js) end up here.
const { errorHandler } = require('./utils/errors');
app.use(errorHandler);

// Frontend is hosted on Vercel — this server is API-only.
app.use((req, res) => {
  res.status(404).json({ error: 'not_found', message: 'Не знайдено' });
});

module.exports = app;
