'use strict';

/**
 * Core picking business logic — extracted from routes/picking.js so it can be
 * tested independently of Express and can be called from other services.
 */

const mongoose = require('mongoose');
const PickingTask = require('../models/PickingTask');
const Product     = require('../models/Product');
const Order       = require('../models/Order');
const DeliveryGroup = require('../models/DeliveryGroup');
const { archiveProduct, getProductTitle } = require('./archiveProduct');
const { getOrderingSchedule } = require('../utils/getOrderingSchedule');
const { getIO } = require('../socket');
const { withLock } = require('../utils/lock');
const { transitionPickingStatus, maybeCompleteSession } = require('../utils/sessionStatus');

// ── Constants ────────────────────────────────────────────────────────────────

const LOCK_TIMEOUT_MS      = 15 * 60 * 1000;            // 15 min — stale worker lock
const FORCE_CLAIM_AFTER_MS =  3 * 60 * 1000;            //  3 min — force-claim guard
const COMPLETED_TTL_MS     = 90 * 24 * 60 * 60 * 1000;  // 90 days — completed-task retention (TTL)

// ── Retry helpers ────────────────────────────────────────────────────────────

function isTransientTxError(err) {
  const directLabels  = Array.isArray(err?.errorLabels) ? err.errorLabels : [];
  const symbolLabels  = Object.getOwnPropertySymbols(err || {})
    .filter((sym) => String(sym).includes('errorLabels'))
    .flatMap((sym) => Array.from(err[sym] || []));
  const labels = [...directLabels, ...symbolLabels];

  return (
    err?.code === 112 ||
    err?.codeName === 'WriteConflict' ||
    labels.includes('TransientTransactionError') ||
    err?.hasErrorLabel?.('TransientTransactionError')
  );
}

async function runTransactionWithRetry(work, maxRetries = 3) {
  for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
    const session = await mongoose.connection.startSession();
    try {
      await session.withTransaction(async () => { await work(session); });
      return;
    } catch (err) {
      if (!isTransientTxError(err) || attempt >= maxRetries) throw err;
      await new Promise((r) => setTimeout(r, 50 * (attempt + 1)));
    } finally {
      await session.endSession();
    }
  }
}

async function runOperationWithRetry(work, maxRetries = 3) {
  for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
    try {
      return await work();
    } catch (err) {
      if (!isTransientTxError(err) || attempt >= maxRetries) throw err;
      await new Promise((r) => setTimeout(r, 50 * (attempt + 1)));
    }
  }
  return null;
}

// ── Core helpers ─────────────────────────────────────────────────────────────

/**
 * Mark Order items as packed for a given product and auto-fulfil the Order
 * when every non-cancelled item is packed.
 */
async function markOrderItemsPacked(taskItems, productId, actor = { by: 'system', byName: '', byRole: 'system' }, session = null) {
  const opts    = session ? { session } : {};

  // Keep one entry PER ORDER (not just the id set): the delivered quantity has to
  // travel with it. A boolean `packed` cannot say "7 of the 10 ordered", so
  // without this the shortfall was lost the moment the task closed.
  const packedByOrder = new Map();
  for (const item of taskItems) {
    if (!item.packed) continue;
    packedByOrder.set(String(item.orderId), item);
  }
  const packedAt = new Date();

  await Promise.all(
    [...packedByOrder.entries()].map(async ([orderId, taskItem]) => {
      const ordered  = Number(taskItem.quantity) || 0;
      // packedQuantity is null only on legacy/system paths that never set it;
      // there "packed" still means the full ordered amount went out.
      const delivered = taskItem.packedQuantity == null ? ordered : Number(taskItem.packedQuantity) || 0;

      const result = await Order.updateOne(
        { _id: orderId, 'items.productId': productId },
        {
          $set: {
            'items.$.packed': true,
            'items.$.packedQuantity': delivered,
            'items.$.shortfallReason': delivered < ordered ? 'short_pick' : null,
            'items.$.packedBy': String(actor.by || ''),
            'items.$.packedByName': String(actor.byName || ''),
            'items.$.packedAt': packedAt,
          },
        },
        opts,
      );
      if (result.matchedCount === 0) return;

      await Order.updateOne(
        {
          _id: orderId,
          status: { $in: ['new', 'in_progress'] },
          // A `skipped` item (late, strict-missed) is terminal and must NOT keep an
          // order from auto-fulfilling — treat it like packed/cancelled here.
          items: { $not: { $elemMatch: { packed: false, cancelled: false, skipped: { $ne: true } } } },
        },
        {
          $set: { status: 'fulfilled' },
          $push: { history: { at: new Date(), ...actor, action: 'status_changed', meta: { from: 'in_progress', to: 'fulfilled', via: 'picking' } } },
        },
        opts,
      );

      // Notify connected clients so the order board updates in real time
      try {
        const order = await Order.findById(orderId, 'buyerTelegramId').lean();
        const io = getIO();
        if (order?.buyerTelegramId) io.emit('user_order_updated', { buyerTelegramId: order.buyerTelegramId });
      } catch { /* non-critical — socket may not be initialised in test env */ }
    })
  );
}

/**
 * Atomically find and lock the next pending task for a worker.
 * Pass 1: fromBlock → end; Pass 2: 1 → fromBlock-1 (wrap-around).
 *
 * deliveryGroupId is REQUIRED. An absent/empty group must never fall through to
 * "the globally-next pending task" — that would lock (and hand a worker) a task
 * from a delivery group they are not picking, silently stealing another group's
 * work. Callers that derive the group from a task (complete / out-of-stock) pass
 * the task's own group; a groupless task simply yields no next task here.
 */
async function findAndLockNext(userTelegramId, fromBlock, deliveryGroupId = null, { actor = {} } = {}) {
  const groupId = deliveryGroupId ? String(deliveryGroupId) : '';
  if (!groupId) return { task: null, wrappedAround: false };

  const lock = { $set: { status: 'locked', lockedBy: userTelegramId, lockedAt: new Date() } };
  const opts = { sort: { blockId: 1, positionIndex: 1 }, new: true };
  const fresh = { status: 'pending', deliveryGroupId: groupId };

  let task = await PickingTask.findOneAndUpdate({ ...fresh, blockId: { $gte: fromBlock } }, lock, opts);
  if (task) {
    await markSessionInProgress(task.orderingSessionId, actor);
    return { task, wrappedAround: false };
  }

  if (fromBlock > 1) {
    task = await PickingTask.findOneAndUpdate(
      { ...fresh, blockId: { $gte: 1, $lt: fromBlock } }, lock, opts,
    );
    if (task) {
      await markSessionInProgress(task.orderingSessionId, actor);
      return { task, wrappedAround: true };
    }
  }

  return { task: null, wrappedAround: false };
}

/**
 * Flip the session confirmed → in_progress the moment the FIRST task is locked.
 *
 * Picking starts when someone takes a product off the shelf, not when they
 * finish it. Until this existed the session sat at 'confirmed' while ten people
 * walked the warehouse, and `cancel-start` — which is gated on 'confirmed' —
 * would happily delete the work they were holding.
 *
 * Idempotent: transitionPickingStatus pins fromStatus='confirmed', so every
 * later lock matches nothing and pushes no duplicate event.
 */
async function markSessionInProgress(orderingSessionId, actor = {}) {
  if (!orderingSessionId) return null;
  return transitionPickingStatus(orderingSessionId, 'in_progress', { actor });
}

/**
 * Release a worker's own lock plus any stale lock older than LOCK_TIMEOUT_MS.
 * Set releaseOwnLocks=false when called from queue-stats polling.
 */
async function releaseWorkerAndStaleLocks(userTelegramId, deliveryGroupId = null, { releaseOwnLocks = true } = {}) {
  const staleLockedAt = new Date(Date.now() - LOCK_TIMEOUT_MS);
  const conditions = [{ lockedAt: { $lt: staleLockedAt } }];
  if (releaseOwnLocks && userTelegramId) conditions.unshift({ lockedBy: String(userTelegramId) });

  await PickingTask.updateMany(
    {
      status: 'locked',
      ...(deliveryGroupId ? { deliveryGroupId: String(deliveryGroupId) } : {}),
      $or: conditions,
    },
    { $set: { status: 'pending', lockedBy: null, lockedAt: null } },
  );
}

/**
 * Enforce the one-task-per-worker invariant: release every OTHER task this
 * worker still holds, keeping `keepTaskId`.
 *
 * Deliberately NOT scoped by deliveryGroupId — a picker physically holds one
 * product at a time, so a lock left behind in another group is exactly the
 * orphan we are cleaning up. `items[].packed` is untouched, so the released
 * task returns to the queue with its partial progress intact.
 *
 * MUST be called only AFTER the new lock is secured. Releasing first and then
 * losing the claim race would leave the worker with nothing while their old
 * task goes back into the queue.
 *
 * @returns {Promise<string[]>} ids of the tasks that were released
 */
async function releaseOtherLocksOfWorker(userTelegramId, keepTaskId) {
  const uid = String(userTelegramId || '');
  if (!uid) return [];

  const filter = {
    status: 'locked',
    lockedBy: uid,
    ...(keepTaskId ? { _id: { $ne: keepTaskId } } : {}),
  };

  const stray = await PickingTask.find(filter, '_id').lean();
  if (!stray.length) return [];

  await PickingTask.updateMany(filter, { $set: { status: 'pending', lockedBy: null, lockedAt: null } });
  return stray.map((t) => String(t._id));
}

/**
 * Complete a picking task: record packed quantities, mark orders, advance to next task.
 *
 * @param {object} opts
 * @param {string}   opts.taskId
 * @param {string}   opts.userTelegramId
 * @param {string}   opts.userFirstName
 * @param {string}   opts.userLastName
 * @param {string}   opts.userRole
 * @param {Array}    opts.items          — [{ orderId, actualQty }]
 * @param {number}   [opts.nextBlock]
 *
 * @returns {{ completedTask, nextTask: object|null }}
 */
async function completePickingTask({ taskId, userTelegramId, userFirstName = '', userLastName = '', userRole = 'warehouse', items = [], nextBlock }) {
  // Cheap pre-check for a fast, clear error before opening a session.
  const pre = await PickingTask.findById(taskId).lean();
  if (!pre) throw Object.assign(new Error('Task not found'), { code: 'picking_task_not_found' });
  if (String(pre.lockedBy || '') !== String(userTelegramId)) throw Object.assign(new Error('Lock expired'), { code: 'expired_lock' });

  const actor = { by: String(userTelegramId), byName: [userFirstName, userLastName].filter(Boolean).join(' '), byRole: userRole };

  let task;
  await runTransactionWithRetry(async (session) => {
    // Re-read + re-verify the lock INSIDE the transaction. Between the pre-check
    // and here another worker may have force-claimed the task (lock stolen);
    // mutating a stale in-memory doc would silently overwrite their work.
    task = await PickingTask.findById(taskId).session(session);
    if (!task) throw Object.assign(new Error('Task not found'), { code: 'picking_task_not_found' });
    if (String(task.lockedBy || '') !== String(userTelegramId)) throw Object.assign(new Error('Lock expired'), { code: 'expired_lock' });

    // The payload must describe EVERY shop of the task and nothing else.
    // Previously a missing orderId silently defaulted to "full quantity delivered",
    // so a truncated / stale request marked shops as fully served without anyone
    // having touched their box. A mismatch means the client's copy of the task is
    // stale (e.g. a late order was appended to it mid-pick) — refuse and let it
    // refetch rather than guess.
    const taskOrderIds  = new Set(task.items.map((i) => String(i.orderId)));
    const inputOrderIds = new Set(items.map((i) => String(i.orderId)));
    const sameCoverage =
      taskOrderIds.size === inputOrderIds.size &&
      [...taskOrderIds].every((id) => inputOrderIds.has(id));
    if (!sameCoverage) {
      throw Object.assign(
        new Error('Submitted shops do not match the task'),
        { code: 'picking_task_items_changed' },
      );
    }

    // Apply actual packed quantities
    for (const taskItem of task.items) {
      const input = items.find((i) => String(i.orderId) === String(taskItem.orderId));
      if (input !== undefined) {
        // Clamp to [0, ordered]: a picker can pack fewer (partial / out of
        // stock) but never MORE than was ordered. Without the upper cap a bad
        // actualQty (typo / fat-finger) propagates into order fulfilment and
        // downstream receipt/reporting as an impossible packed count.
        const ordered = Number(taskItem.quantity) || 0;
        taskItem.packedQuantity = Math.min(ordered, Math.max(0, Number(input.actualQty) || 0));
      } else {
        taskItem.packedQuantity = taskItem.quantity;
      }
      taskItem.packed = taskItem.packedQuantity > 0;
    }

    task.status   = 'completed';
    task.lockedBy = null;
    task.lockedAt = null;
    task.completionReason = 'packed';
    // Stamp the finaliser for session-scoped shift-board ranking (lockedBy is
    // about to be cleared, so this is the only surviving record of who picked it).
    task.completedBy     = String(userTelegramId);
    task.completedByName  = actor.byName;
    task.completedExpireAt = new Date(Date.now() + COMPLETED_TTL_MS); // TTL reap after 90d

    await task.save({ session });
    await markOrderItemsPacked(task.items, task.productId, actor, session);

    // First completion of this session flips it to "В роботі" (in_progress).
    // Idempotent: only confirmed → in_progress matches; later completions no-op.
    if (task.orderingSessionId) {
      await transitionPickingStatus(
        task.orderingSessionId, 'in_progress', { actor: { by: actor.by, byName: actor.byName } }, session,
      );
    }
  });

  // After commit: if this was the last active task of the session, mark it
  // completed (всі товари зібрані). Idempotent + concurrency-safe.
  if (task.orderingSessionId) {
    await maybeCompleteSession(task.orderingSessionId, { actor: { by: actor.by, byName: actor.byName } });
  }

  const fromBlock = typeof nextBlock === 'number' ? nextBlock : task.blockId;
  const { task: nextRaw, wrappedAround } = await findAndLockNext(userTelegramId, fromBlock, task.deliveryGroupId || null);

  return { completedTask: task.toObject(), nextTask: nextRaw ? nextRaw.toObject() : null, wrappedAround };
}

/**
 * Mark a task as out-of-stock: record which shops were served, archive the product.
 *
 * @returns {{ nextTask: object|null }}
 */
async function outOfStockPickingTask({ taskId, userTelegramId, userFirstName = '', userLastName = '', userRole = 'warehouse', packedOrderIds = [], nextBlock }) {
  let task = await PickingTask.findById(taskId);
  if (!task) throw Object.assign(new Error('Task not found'), { code: 'picking_task_not_found' });

  // Built up front: the crash-retry branch below archives too, and it must stamp
  // the same picker on the affected orders' history as the normal path does.
  const actor = { by: String(userTelegramId), byName: [userFirstName, userLastName].filter(Boolean).join(' '), byRole: userRole };

  // Idempotency: task already completed (crashed after phase 1) — just retry archive.
  //
  // Gated on the RECORDED reason, never on status alone. 'completed' says the task
  // is finished, not why: replaying this request on a normally-packed task (stale
  // tab, duplicate submit, manual retry after a network blip) used to archive an
  // in-stock product. A retry is only a retry when the original was an OOS.
  if (task.status === 'completed') {
    if (task.completionReason !== 'out_of_stock') {
      throw Object.assign(
        new Error('Task was already completed as a normal pick'),
        { code: 'picking_oos_already_packed' },
      );
    }
    const productForRetry = await Product.findById(task.productId);
    if (productForRetry && productForRetry.status !== 'archived') {
      // archiveProduct now retries transient tx errors internally.
      await archiveProduct(productForRetry, { notifyBuyers: false, bot: null, reason: 'out_of_stock', actor });
    }
    const fromBlockRetry = typeof nextBlock === 'number' ? nextBlock : task.blockId;
    const { task: nextRaw, wrappedAround } = await findAndLockNext(userTelegramId, fromBlockRetry, task.deliveryGroupId || null);
    return { nextTask: nextRaw ? nextRaw.toObject() : null, wrappedAround };
  }

  // Auto-claim if still pending (called from review list)
  if (task.status === 'pending') {
    const claimed = await PickingTask.findOneAndUpdate(
      { _id: task._id, status: 'pending' },
      { $set: { status: 'locked', lockedBy: userTelegramId, lockedAt: new Date() } },
      { new: true },
    );
    if (!claimed) throw Object.assign(new Error('Task taken by another worker'), { code: 'picking_claim_taken_by_other' });
    task = claimed;
  } else if (String(task.lockedBy || '') !== String(userTelegramId)) {
    throw Object.assign(new Error('Lock expired'), { code: 'expired_lock' });
  }

  await task.populate('productId');

  const packedSet = new Set(packedOrderIds.map(String));

  // Phase 1: atomic task + order update.
  // Re-read + re-verify the task INSIDE the transaction (mirrors the hardening
  // already in completePickingTask). Between the initial findById above and
  // here a concurrent progress-PATCH or force-claim may have mutated the task;
  // saving the stale in-memory doc would silently overwrite their work.
  await runTransactionWithRetry(async (session) => {
    const fresh = await PickingTask.findById(task._id).session(session);
    if (!fresh) throw Object.assign(new Error('Task not found'), { code: 'picking_task_not_found' });
    // Finalised by a retry / other path between the findById above and here.
    // Same rule as the pre-check: only a prior OOS may fall through to phase 2,
    // otherwise this would archive a product someone just packed normally.
    if (fresh.status === 'completed') {
      if (fresh.completionReason !== 'out_of_stock') {
        throw Object.assign(
          new Error('Task was already completed as a normal pick'),
          { code: 'picking_oos_already_packed' },
        );
      }
      return;
    }
    if (String(fresh.lockedBy || '') !== String(userTelegramId)) {
      throw Object.assign(new Error('Lock expired'), { code: 'expired_lock' });
    }
    for (const item of fresh.items) {
      const wasPacked = packedSet.has(String(item.orderId));
      item.packedQuantity = wasPacked ? item.quantity : 0;
      item.packed = wasPacked;
    }
    fresh.status   = 'completed';
    fresh.lockedBy = null;
    fresh.lockedAt = null;
    fresh.completionReason = 'out_of_stock';
    // Out-of-stock is still a picker action — credit it on the shift board.
    fresh.completedBy     = String(userTelegramId);
    fresh.completedByName  = actor.byName;
    fresh.completedExpireAt = new Date(Date.now() + COMPLETED_TTL_MS); // TTL reap after 90d
    await fresh.save({ session });
    await markOrderItemsPacked(fresh.items, fresh.productId, actor, session);
    task = fresh; // keep downstream block/product lookups consistent

    if (fresh.orderingSessionId) {
      await transitionPickingStatus(
        fresh.orderingSessionId, 'in_progress', { actor: { by: actor.by, byName: actor.byName } }, session,
      );
    }
  });

  // Phase 2: archive product (idempotent on retry via completed-status guard above)
  const productDoc = await Product.findById(task.productId._id || task.productId);
  if (productDoc && productDoc.status !== 'archived') {
    // archiveProduct now retries transient tx errors internally.
    await archiveProduct(productDoc, { notifyBuyers: false, bot: null, reason: 'out_of_stock', actor });
  }

  if (task.orderingSessionId) {
    await maybeCompleteSession(task.orderingSessionId, { actor: { by: actor.by, byName: actor.byName } });
  }

  const fromBlock = typeof nextBlock === 'number' ? nextBlock : task.blockId;
  const { task: nextRaw, wrappedAround } = await findAndLockNext(userTelegramId, fromBlock, task.deliveryGroupId || null);
  return { nextTask: nextRaw ? nextRaw.toObject() : null, wrappedAround };
}

/**
 * Force-claim a task locked by another worker (allowed only after FORCE_CLAIM_AFTER_MS).
 *
 * @returns {{ task: object }}
 */
async function forceClaimPickingTask({ taskId, userTelegramId }) {
  const task = await PickingTask.findById(taskId);
  if (!task) throw Object.assign(new Error('Task not found'), { code: 'picking_task_not_found' });

  if (task.status === 'pending') {
    const claimed = await PickingTask.findOneAndUpdate(
      { _id: task._id, status: 'pending' },
      { $set: { status: 'locked', lockedBy: userTelegramId, lockedAt: new Date() } },
      { new: true },
    );
    if (!claimed) throw Object.assign(new Error('Task unavailable'), { code: 'picking_claim_unavailable' });
    await releaseOtherLocksOfWorker(userTelegramId, claimed._id);
    await markSessionInProgress(claimed.orderingSessionId, { by: String(userTelegramId) });
    return { task: claimed.toObject() };
  }

  if (task.status !== 'locked') throw Object.assign(new Error('Task unavailable'), { code: 'picking_claim_unavailable' });

  const lockedAgo = Date.now() - new Date(task.lockedAt).getTime();
  if (lockedAgo < FORCE_CLAIM_AFTER_MS) {
    const tooSoonErr = Object.assign(new Error(`Too soon: locked ${Math.round(lockedAgo / 1000)}s ago`), { code: 'picking_claim_too_soon', lockedAgo });
    throw tooSoonErr;
  }

  // Pin lockedBy + lockedAt to the doc we evaluated the 3-min guard against.
  // Without this the update matches on `status:'locked'` alone, so:
  //   - two workers can both pass the guard and both findOneAndUpdate → the
  //     second silently re-steals, yet BOTH clients receive a task they think
  //     they own (double picking); and
  //   - a worker who legitimately (re)claimed the task 1s ago can be stolen
  //     from by someone whose in-memory copy still shows the old, stale lock.
  // If anything changed since we read, the filter matches nothing → the caller
  // gets picking_claim_unavailable and re-syncs from the live queue.
  const claimed = await PickingTask.findOneAndUpdate(
    { _id: task._id, status: 'locked', lockedBy: task.lockedBy, lockedAt: task.lockedAt },
    { $set: { status: 'locked', lockedBy: userTelegramId, lockedAt: new Date() } },
    { new: true },
  );
  if (!claimed) throw Object.assign(new Error('Task unavailable'), { code: 'picking_claim_unavailable' });
  await releaseOtherLocksOfWorker(userTelegramId, claimed._id);
  await markSessionInProgress(claimed.orderingSessionId, { by: String(userTelegramId) });
  return { task: claimed.toObject() };
}

/**
 * Reconcile active tasks with one ordering session:
 * removes items belonging to orders outside the session, drops empty tasks.
 */
async function reconcileActiveTasksForSession(deliveryGroupId, orderingSessionId) {
  const groupId   = String(deliveryGroupId  || '');
  const sessionId = String(orderingSessionId || '');
  if (!groupId || !sessionId) return { deletedCount: 0, trimmedCount: 0 };

  const currentOrders = await Order.find(
    { 'buyerSnapshot.deliveryGroupId': groupId, status: { $in: ['new', 'in_progress'] }, orderingSessionId: sessionId },
    '_id',
  ).lean();
  const allowedOrderIds = new Set(currentOrders.map((o) => String(o._id)));

  const activeTasks = await PickingTask.find(
    { deliveryGroupId: groupId, status: { $in: ['pending', 'locked'] } },
    '_id status items',
  ).lean();

  if (!activeTasks.length) return { deletedCount: 0, trimmedCount: 0 };

  let deletedCount = 0;
  let trimmedCount = 0;
  const ops = [];

  for (const task of activeTasks) {
    const keptItems = (task.items || []).filter((it) => allowedOrderIds.has(String(it.orderId)));
    if (keptItems.length === (task.items || []).length) continue;

    if (!keptItems.length) {
      const hasPackedProgress = (task.items || []).some((it) => it.packed);
      if (hasPackedProgress) continue; // never delete a task with partial progress
      ops.push({ deleteOne: { filter: { _id: task._id, status: { $in: ['pending', 'locked'] } } } });
      deletedCount += 1;
    } else {
      ops.push({ updateOne: { filter: { _id: task._id, status: { $in: ['pending', 'locked'] } }, update: { $set: { items: keptItems } } } });
      trimmedCount += 1;
    }
  }

  if (ops.length) await PickingTask.bulkWrite(ops, { ordered: false });
  return { deletedCount, trimmedCount };
}

/**
 * Recover from a crash where an out-of-stock task was marked `completed` (phase 1)
 * but its product was never archived (phase 2). Re-runs archiveProduct for each
 * affected product.
 *
 * Fired fire-and-forget on every next-task poll, so it is serialised per group
 * (skip-if-busy) and processes products sequentially with retries — see impl.
 */
async function archiveOrphanedOutOfStockProducts(deliveryGroupId) {
  const groupId = String(deliveryGroupId || '');
  if (!groupId) return { fixedCount: 0 };

  // waitMs: 0 → if a sweep for this group is already running, skip immediately
  // instead of queueing. Concurrent sweeps each spawn archiveProduct
  // transactions that all shift the same orderNumber space (shiftDown) and
  // deadlock with "Write conflict ... yielding is disabled".
  try {
    return await withLock(
      `picking:orphan-archive:${groupId}`,
      () => archiveOrphanedOutOfStockProductsImpl(groupId),
      { ttlMs: 120_000, waitMs: 0 },
    );
  } catch (err) {
    if (err && (err.code === 'lock_busy' || err.errorCode === 'lock_busy')) return { fixedCount: 0 };
    throw err;
  }
}

async function archiveOrphanedOutOfStockProductsImpl(groupId) {
  // Only OUT-OF-STOCK completions need archiving. A normal completion packs
  // every shop (all items.packed === true) and the product MUST stay active for
  // future sessions. An out-of-stock completion (full or partial) always leaves
  // at least one item with packed === false. Without this $elemMatch filter the
  // sweep archived in-stock products that had just been packed normally.
  const completedTasks = await PickingTask.find(
    {
      deliveryGroupId: groupId,
      status: 'completed',
      items: { $elemMatch: { packed: false } },
      // Skip tasks whose archive intent was deliberately consumed by a
      // product restore-from-archive — otherwise restore is silently undone
      // on the next poll (the product is re-archived). See models/PickingTask.
      archiveReconciled: { $ne: true },
    },
    'productId',
  ).sort({ updatedAt: -1 }).limit(200).lean();

  if (!completedTasks.length) return { fixedCount: 0 };

  const productIds = [...new Set(completedTasks.map((t) => String(t.productId)))];
  let fixedCount   = 0;

  // Sequential (NOT Promise.all): each archiveProduct runs shiftDown over the
  // same orderNumber range, so parallel calls write-conflict. Each is retried on
  // transient transaction errors.
  for (const pid of productIds) {
    try {
      const product = await Product.findOne({ _id: pid, status: { $ne: 'archived' } });
      if (!product) continue;
      const activeTask = await PickingTask.findOne({ productId: product._id, status: { $in: ['pending', 'locked'] } }).lean();
      if (activeTask) continue;
      // Re-read at archive time: a concurrent product restore-from-archive may have
      // consumed the OOS signal (archiveReconciled=true) AFTER this sweep's initial
      // find() snapshot. Without re-checking, a sweep that is still grinding through
      // a large backlog could re-archive a product that was just restored. Restore
      // must win, so skip if no unreconciled OOS task remains for this product.
      const orphanTask = await PickingTask.findOne(
        { productId: product._id, status: 'completed', 'items.packed': false, archiveReconciled: { $ne: true } },
        '_id',
      ).lean();
      if (!orphanTask) continue;
      // archiveProduct retries transient tx errors internally; the per-group
      // lock + sequential loop already prevent concurrent shiftDown conflicts.
      await archiveProduct(product, { notifyBuyers: false, bot: null, reason: 'system_archive' });
      fixedCount += 1;
    } catch (err) {
      console.warn(`[pickingService] orphan archive failed for ${pid}:`, err.message);
    }
  }

  return { fixedCount };
}

module.exports = {
  LOCK_TIMEOUT_MS,
  FORCE_CLAIM_AFTER_MS,
  markOrderItemsPacked,
  findAndLockNext,
  releaseWorkerAndStaleLocks,
  releaseOtherLocksOfWorker,
  markSessionInProgress,
  completePickingTask,
  outOfStockPickingTask,
  forceClaimPickingTask,
  reconcileActiveTasksForSession,
  archiveOrphanedOutOfStockProducts,
  runTransactionWithRetry,
  runOperationWithRetry,
};
