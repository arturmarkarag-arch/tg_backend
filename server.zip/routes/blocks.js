const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Block = require('../models/Block');
const Counter = require('../models/Counter');
const Product = require('../models/Product');
const { getIO } = require('../socket');
const { requireTelegramRoles } = require('../middleware/telegramAuth');
const { appError, asyncHandler } = require('../utils/errors');
const { refreshPickingTaskPositions } = require('../services/taskBuilder');
const { syncMirror } = require('../utils/upsertShopProduct');

// On the "Полки" board a product tile renders ONLY its photo (+ name as the
// alt/placeholder letter). Everything else on the warehouse Product — price,
// quantity, barcode, aiDescription, labelPositions, pendingShopUpdate,
// storeLinks, … — is dead weight here, and a single block can hold 200+
// products, so populating full docs ships hundreds of KB per board read for
// nothing. Project just what ProductImage + the card need. (`_id` is implicit.)
const BLOCK_PRODUCT_FIELDS = 'name imageUrls localImageUrl originalImageUrl';

async function repairBlockMissingProducts(blockId, session = null) {
  const block = await Block.findOne({ blockId }).select('productIds').session(session).lean();
  if (!block || !(block.productIds || []).length) return;

  const existingProducts = await Product.find({ _id: { $in: block.productIds } }, '_id').session(session).lean();
  const existingIds = new Set(existingProducts.map((p) => String(p._id)));
  const filteredIds = block.productIds.filter((id) => existingIds.has(String(id)));
  if (filteredIds.length === block.productIds.length) return;

  await Block.updateOne(
    { blockId },
    { $set: { productIds: filteredIds }, $inc: { version: 1 } },
    { session }
  );
}

async function emitPositionUpdates() {
  try {
    const changed = await refreshPickingTaskPositions();
    if (changed.length) {
      getIO()?.emit('picking_tasks_positions_updated', changed);
    }
  } catch (err) {
    console.error('[blocks] position refresh error:', err);
  }
}

function slimBlock(block) {
  return {
    blockId: block.blockId,
    version: block.version,
    productIds: (block.productIds || []).map((id) => String(id._id || id)),
  };
}

const staffOnly = requireTelegramRoles(['admin', 'warehouse']);

// GET /api/blocks — all blocks with product count, or paginated blocks when limit/offset are supplied
router.get('/', asyncHandler(async (req, res) => {
  const limit = req.query.limit ? Number(req.query.limit) : undefined;
  const offset = req.query.offset ? Number(req.query.offset) : 0;
  const query = Block.find().sort('blockId');

  if (limit !== undefined) {
    query.skip(offset).limit(limit);
  }

  const blocks = await query
    .populate({ path: 'productIds', match: { status: { $in: ['active', 'pending'] } }, select: BLOCK_PRODUCT_FIELDS })
    .lean();

  if (limit !== undefined) {
    const [total, maxDoc] = await Promise.all([
      Block.countDocuments(),
      Block.findOne({}, 'blockId').sort({ blockId: -1 }).lean(),
    ]);
    return res.json({ items: blocks, total, maxBlockId: maxDoc?.blockId ?? 0 });
  }

  res.json(blocks);
}));

async function getNextBlockId() {
  const maxBlock = await Block.findOne({}, 'blockId').sort({ blockId: -1 }).lean();
  const maxBlockId = maxBlock ? maxBlock.blockId : 0;

  while (true) {
    const counter = await Counter.findOne({ name: 'blockId' }).lean();
    if (!counter) {
      try {
        const created = await Counter.create({ name: 'blockId', seq: maxBlockId + 1 });
        return created.seq;
      } catch (err) {
        if (err.code === 11000) {
          continue;
        }
        throw err;
      }
    }

    if (counter.seq < maxBlockId) {
      const updated = await Counter.findOneAndUpdate(
        { name: 'blockId', seq: counter.seq },
        { $set: { seq: maxBlockId } },
        { new: true }
      ).lean();
      if (!updated) {
        continue;
      }
    }

    const updatedCounter = await Counter.findOneAndUpdate(
      { name: 'blockId' },
      { $inc: { seq: 1 } },
      { new: true }
    ).lean();
    return updatedCounter.seq;
  }
}

// POST /api/blocks — create a new block with the next sequential blockId
router.post('/', staffOnly, asyncHandler(async (req, res) => {
  const MAX_RETRIES = 5;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt += 1) {
    try {
      const nextBlockId = await getNextBlockId();
      const block = await Block.create({ blockId: nextBlockId, productIds: [] });
      const created = block.toObject();

      try {
        const io = getIO();
        io.emit('block_updated', slimBlock(created));
      } catch (e) {
        console.warn('[blocks/create] socket emit failed:', e.message);
      }

      return res.status(201).json(created);
    } catch (err) {
      if (err.code === 11000 && attempt < MAX_RETRIES) {
        continue;
      }
      console.error('[blocks/create] Error:', err);
      if (err.code === 11000) throw appError('block_id_conflict');
      throw appError('block_create_failed');
    }
  }

  throw appError('block_id_conflict');
}));

// GET /api/blocks/incoming/products — products not assigned to any block.
// qty>0 hides normal receipts that have nothing to place, but restoredFromArchive
// items are surfaced regardless of quantity — restore lands them with qty=0
// pending the worker's physical count, so they must be visible to be bumpable.
// See [[product-restore-from-archive]].
router.get('/incoming/products', asyncHandler(async (req, res) => {
  const assignedIds = await Block.distinct('productIds');
  const products = await Product.find({
    // Надходження = NOT in a block, awaiting placement → 'pending' (active⟺in-block).
    status: 'pending',
    source: { $in: ['receive', 'receipt'] },
    _id: { $nin: assignedIds },
    $or: [
      { quantity: { $gt: 0 } },
      { restoredFromArchive: true },
    ],
  })
    .sort('-createdAt')
    .lean();
  res.json(products);
}));

// GET /api/blocks/search/products?q=term — search products across all blocks
router.get('/search/products', asyncHandler(async (req, res) => {
  const q = req.query.q;
  if (!q) throw appError('block_search_query_required');

  const products = await Product.find({
    $or: [
      { brand: { $regex: q, $options: 'i' } },
      { model: { $regex: q, $options: 'i' } },
      { category: { $regex: q, $options: 'i' } },
    ],
  }).lean();

  res.json(products);
}));

// GET /api/blocks/:number — single block with populated products
router.get('/:number', asyncHandler(async (req, res) => {
  const num = Number(req.params.number);
  if (!num || num < 1) throw appError('block_invalid_number');

  await repairBlockMissingProducts(num);

  const block = await Block.findOne({ blockId: num })
    .populate({ path: 'productIds', match: { status: { $in: ['active', 'pending'] } }, select: BLOCK_PRODUCT_FIELDS })
    .lean();
  if (!block) throw appError('block_not_found');
  res.json(block);
}));

// POST /api/blocks/move — move product between blocks
router.post('/move', staffOnly, asyncHandler(async (req, res) => {
  const { productId, fromBlock, toBlock, toIndex, expectedFromVersion, expectedToVersion } = req.body;
  const fromBlockId = Number(fromBlock);
  const toBlockId = Number(toBlock);
  const index = Number(toIndex);

  if (
    !productId ||
    !Number.isInteger(fromBlockId) ||
    !Number.isInteger(toBlockId) ||
    !Number.isInteger(index)
  ) {
    throw appError('block_move_invalid_fields');
  }

  let updatedSource;
  let updatedTarget;
  let sourceId;
  let targetId;
  let isSameBlock = false;

  const session = await mongoose.connection.startSession();
  try {
    await session.withTransaction(async () => {
      const source = await Block.findOne({ blockId: fromBlockId }).session(session);
      const target = fromBlockId === toBlockId
        ? source
        : await Block.findOne({ blockId: toBlockId }).session(session);

      if (!source || !target) throw appError('block_not_found');

      // Optimistic lock — refuse if any provided expected version is stale.
      if (expectedFromVersion != null && Number(expectedFromVersion) !== source.version) {
        throw appError('block_stale', { blockId: source.blockId, currentVersion: source.version });
      }
      if (
        fromBlockId !== toBlockId &&
        expectedToVersion != null &&
        Number(expectedToVersion) !== target.version
      ) {
        throw appError('block_stale', { blockId: target.blockId, currentVersion: target.version });
      }

      const idx = source.productIds.findIndex((id) => id.toString() === productId);
      if (idx === -1) throw appError('product_not_in_source_block');

      source.productIds.splice(idx, 1);
      const safeIndex = Math.min(Math.max(0, index), target.productIds.length);
      target.productIds.splice(safeIndex, 0, productId);

      if (fromBlockId === toBlockId) {
        source.version += 1;
        await source.save({ session });
      } else {
        source.version += 1;
        target.version += 1;
        await source.save({ session });
        await target.save({ session });
      }

      // Зберігаємо лише ID збережених документів. populate без { session }
      // читав би поза snapshot транзакції — клієнт міг отримати застарілі
      // або, навпаки, ще не закомічені дані. Робимо populate ПІСЛЯ commit.
      sourceId = source._id;
      targetId = target._id;
      isSameBlock = fromBlockId === toBlockId;
    });
  } finally {
    session.endSession();
  }

  updatedSource = await Block.findById(sourceId)
    .populate({ path: 'productIds', match: { status: { $in: ['active', 'pending'] } }, select: BLOCK_PRODUCT_FIELDS })
    .lean();
  updatedTarget = isSameBlock
    ? updatedSource
    : await Block.findById(targetId)
        .populate({ path: 'productIds', match: { status: { $in: ['active', 'pending'] } }, select: BLOCK_PRODUCT_FIELDS })
        .lean();

  try {
    const io = getIO();
    io.emit('block_updated', slimBlock(updatedSource));
    if (fromBlockId !== toBlockId) {
      io.emit('block_updated', slimBlock(updatedTarget));
    }
  } catch (_) {}

  emitPositionUpdates();
  res.json({ source: updatedSource, target: updatedTarget });
}));

// DELETE /api/blocks/:number/products/:productId — remove product from block (returns it to incoming)
//
// Реалізовано як атомарний findOneAndUpdate з $pull + $inc(version), бо
// раніше findOne -> splice -> save() мав race condition: дві паралельні
// DELETE без expectedVersion читали один і той самий productIds, кожен
// видаляв свій id, останній save() перетирав попередній — видалений товар
// «повертався» у блок. Тепер write проходить лише при збігу version.
router.delete('/:number/products/:productId', staffOnly, asyncHandler(async (req, res) => {
  const num = Number(req.params.number);
  const { productId } = req.params;
  if (!num || num < 1) throw appError('block_invalid_number');
  if (!mongoose.Types.ObjectId.isValid(productId)) throw appError('block_invalid_product_id');

  // Optimistic lock can be passed via query or header to keep DELETE body-free.
  const expectedVersionRaw = req.query.expectedVersion ?? req.get('if-match');
  const expectedVersion = expectedVersionRaw != null ? Number(expectedVersionRaw) : null;

  const MAX_RETRIES = 5;
  let updatedRaw = null;
  for (let attempt = 0; attempt < MAX_RETRIES; attempt += 1) {
    const current = await Block.findOne({ blockId: num }).lean();
    if (!current) throw appError('block_not_found');

    if (expectedVersion != null && expectedVersion !== current.version) {
      throw appError('block_stale', { currentVersion: current.version });
    }

    if (!current.productIds.some((id) => String(id) === String(productId))) {
      throw appError('product_not_in_block');
    }

    const versionToMatch = expectedVersion != null ? expectedVersion : current.version;
    updatedRaw = await Block.findOneAndUpdate(
      { blockId: num, version: versionToMatch, productIds: productId },
      { $pull: { productIds: productId }, $inc: { version: 1 } },
      { new: true },
    );
    if (updatedRaw) break;

    // Збій збігу версії: якщо клієнт надіслав expectedVersion — це stale,
    // повідомляємо явно. Інакше — паралельний запис; читаємо свіжу версію
    // і повторюємо.
    if (expectedVersion != null) {
      const refreshed = await Block.findOne({ blockId: num }).lean();
      throw appError('block_stale', { currentVersion: refreshed?.version });
    }
  }
  if (!updatedRaw) throw appError('block_concurrent_modification');

  // Out of every block ⟹ back to warehouse 'pending' (findable in Надходження),
  // never left as an 'active' orphan that nobody can locate. Archived stays archived.
  await Product.updateOne(
    { _id: productId, status: { $ne: 'archived' } },
    { $set: { status: 'pending' } },
  );

  const updated = await Block.findById(updatedRaw._id)
    .populate({ path: 'productIds', match: { status: { $in: ['active', 'pending'] } }, select: BLOCK_PRODUCT_FIELDS })
    .lean();

  try {
    const io = getIO();
    io.emit('block_updated', slimBlock(updated));
    io.emit('incoming_updated');
    io.emit('catalogue_updated', { action: 'add' });
  } catch (_) {}

  emitPositionUpdates();
  res.json(updated);
}));

// POST /api/blocks/:number/add — add product to block
//
// Атомарно через findOneAndUpdate з фільтром по version. Унікальний multikey-
// індекс на productIds — фінальний бар'єр від race condition між двома різними
// блоками: якщо два запити одночасно намагаються додати один і той же товар
// у різні блоки, другий отримає duplicate-key (E11000) і ми повертаємо
// product_in_other_block з актуальним номером блока.
router.post('/:number/add', staffOnly, asyncHandler(async (req, res) => {
  const num = Number(req.params.number);
  const { productId, index, expectedVersion } = req.body;
  if (!num || num < 1) throw appError('block_invalid_number');
  if (!productId) throw appError('block_missing_product_id');
  if (!mongoose.Types.ObjectId.isValid(productId)) throw appError('block_invalid_product_id');

  // INVARIANT (server-enforced): a product becomes 'active' the instant it enters
  // a block, and an archived product may NEVER be shelved (restore it first).
  // This is the single gate — no client path can place a non-active product into
  // a block, so "in a block" is always equivalent to "active / orderable".
  const productDoc = await Product.findById(productId, 'status').lean();
  if (!productDoc) throw appError('product_not_found');
  if (productDoc.status === 'archived') throw appError('product_archived_cannot_shelve');

  const MAX_RETRIES = 5;
  let updatedRaw = null;
  for (let attempt = 0; attempt < MAX_RETRIES; attempt += 1) {
    const current = await Block.findOne({ blockId: num }).lean();
    if (!current) throw appError('block_not_found');

    if (expectedVersion != null && Number(expectedVersion) !== current.version) {
      throw appError('block_stale', { currentVersion: current.version });
    }

    // М'яка попередня перевірка для людського повідомлення (з номером блока).
    // Жорсткий гарант — унікальний індекс нижче.
    const existing = await Block.findOne({ productIds: productId }).lean();
    if (existing) {
      if (existing.blockId === num) {
        throw appError('product_already_in_block', { existingBlockId: existing.blockId });
      }
      throw appError('product_in_other_block', { existingBlockId: existing.blockId });
    }

    // Build the "visible" (client-side) productIds — same subset the client renders.
    // Dangling IDs (products deleted without being $pull-ed from the block) cause a
    // mismatch: client's drop-zone index is based on the visible count, but the raw
    // array is longer, so $position ends up before the visible products.
    const rawIds = current.productIds || [];
    let rawPosition;
    if (rawIds.length === 0 || index == null) {
      rawPosition = rawIds.length; // append at end
    } else {
      const visibleDocs = await Product.find(
        { _id: { $in: rawIds }, status: { $in: ['active', 'pending'] } },
        '_id',
      ).lean();
      const visibleIdSet = new Set(visibleDocs.map((p) => String(p._id)));

      // Prune dangling IDs atomically before inserting so future reads are clean
      const danglingIds = rawIds.filter((id) => !visibleIdSet.has(String(id)));
      if (danglingIds.length) {
        const versionForClean = expectedVersion != null ? Number(expectedVersion) : current.version;
        await Block.updateOne(
          { blockId: num, version: versionForClean },
          { $pull: { productIds: { $in: danglingIds } }, $inc: { version: 1 } },
        );
        continue; // retry with fresh current after cleanup
      }

      // Map visible index → raw position (they are equal when no dangling IDs, i.e. the common case)
      const visibleIds = rawIds.filter((id) => visibleIdSet.has(String(id)));
      const clampedVisible = Math.min(Math.max(0, Number(index)), visibleIds.length);

      if (clampedVisible === 0) {
        rawPosition = rawIds.findIndex((id) => visibleIdSet.has(String(id)));
        if (rawPosition === -1) rawPosition = rawIds.length;
      } else {
        let seen = 0;
        rawPosition = rawIds.length; // default: append
        for (let i = 0; i < rawIds.length; i++) {
          if (visibleIdSet.has(String(rawIds[i]))) {
            seen++;
            if (seen === clampedVisible) { rawPosition = i + 1; break; }
          }
        }
      }
    }

    const versionToMatch = expectedVersion != null ? Number(expectedVersion) : current.version;

    try {
      updatedRaw = await Block.findOneAndUpdate(
        { blockId: num, version: versionToMatch },
        {
          $push: { productIds: { $each: [productId], $position: rawPosition } },
          $inc: { version: 1 },
        },
        { new: true },
      );
    } catch (err) {
      if (err.code === 11000) {
        // Race програно: інший паралельний запит уже розмістив цей товар.
        const placed = await Block.findOne({ productIds: productId }).lean();
        if (placed) {
          if (placed.blockId === num) {
            throw appError('product_already_in_block', { existingBlockId: placed.blockId });
          }
          throw appError('product_in_other_block', { existingBlockId: placed.blockId });
        }
      }
      throw err;
    }

    if (updatedRaw) break;

    if (expectedVersion != null) {
      const refreshed = await Block.findOne({ blockId: num }).lean();
      throw appError('block_stale', { currentVersion: refreshed?.version });
    }
  }
  if (!updatedRaw) throw appError('block_concurrent_modification');

  // In-block ⟹ active (invariant). Idempotent; the product just entered a block.
  await Product.updateOne({ _id: productId }, { $set: { status: 'active' } });

  // This is THE normal activation path (receive/restore → Надходження → block), so
  // the ShopProduct mirror must be created/refreshed HERE — previously only the
  // products.js PATCH did it, leaving block-added (incl. restored) products active on
  // the warehouse but absent/stale in "Товари Магазинів". Fire-and-forget — the mirror
  // is a projection, never part of this request's contract.
  const activatedProduct = await Product.findById(productId);
  if (activatedProduct) {
    syncMirror(activatedProduct).catch((err) =>
      console.error('[blocks/add] mirror sync failed:', err.message));
  }

  const updated = await Block.findById(updatedRaw._id)
    .populate({ path: 'productIds', match: { status: { $in: ['active', 'pending'] } }, select: BLOCK_PRODUCT_FIELDS })
    .lean();

  // Broadcast to all clients so they see the update in real time.
  // catalogue_updated signals sellers that a new product appeared in the catalogue.
  try {
    const io = getIO();
    io.emit('block_updated', slimBlock(updated));
    io.emit('catalogue_updated', { action: 'add' });
  } catch (_) { /* socket not initialized yet */ }

  emitPositionUpdates();
  res.json(updated);
}));

// DELETE /api/blocks/:number — only allowed when block is empty
router.delete('/:number', requireTelegramRoles(['admin', 'manager']), asyncHandler(async (req, res) => {
  const num = parseInt(req.params.number, 10);
  if (isNaN(num)) throw appError(400, 'Invalid block number');

  const block = await Block.findOne({ blockId: num }).lean();
  if (!block) throw appError(404, 'Block not found');

  const activeCount = await Product.countDocuments({
    _id: { $in: block.productIds || [] },
    status: { $in: ['active', 'pending'] },
  });
  if (activeCount > 0) throw appError(409, 'Block is not empty');

  await Block.deleteOne({ blockId: num });

  try {
    const io = getIO();
    io.emit('block_deleted', { blockId: num });
  } catch (_) { /* socket not ready */ }

  res.json({ ok: true, blockId: num });
}));

module.exports = router;
