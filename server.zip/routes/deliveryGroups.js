const express = require('express');
const mongoose = require('mongoose');
const { appError, asyncHandler } = require('../utils/errors');
const DeliveryGroup = require('../models/DeliveryGroup');
const User = require('../models/User');
const Order = require('../models/Order');
const Shop = require('../models/Shop');
const PickingTask = require('../models/PickingTask');
const CatalogReview = require('../models/CatalogReview');
const { telegramAuth, requireTelegramRole, requireTelegramRoles } = require('../middleware/telegramAuth');
const {
  isOrderingOpen,
  getWindowDescription,
  getOrderingWindowOpenAt,
} = require('../utils/orderingSchedule');
const { getOrCreateSessionId } = require('../utils/getOrCreateSession');
const { pushSessionEvent } = require('../utils/sessionStatus');
const { normalizeDeliveryGroup } = require('../utils/deliveryGroupHelpers');
const { getIO } = require('../socket');

const { getOrderingSchedule } = require('../utils/getOrderingSchedule');
const cache = require('../utils/cache');
const { invalidateDeliveryGroup } = require('../utils/modelCache');

async function getAllDeliveryGroups() {
  let groups = await cache.get(cache.KEYS.DELIVERY_GROUPS);
  if (!groups) {
    groups = await DeliveryGroup.find().lean();
    await cache.set(cache.KEYS.DELIVERY_GROUPS, groups);
  }
  return groups;
}

const router = express.Router();

async function buildDeliveryGroupSessionSummary(group, schedule, ordersByGroup) {
  const normalizedGroup = normalizeDeliveryGroup(group);
  const status = isOrderingOpen(normalizedGroup.dayOfWeek, schedule);
  const currentSessionId = await getOrCreateSessionId(String(normalizedGroup._id), normalizedGroup.dayOfWeek, schedule);
  const sessionOpenAt = getOrderingWindowOpenAt(normalizedGroup.dayOfWeek, schedule);
  const orders = ordersByGroup[String(group._id)] || [];
  const summary = orders.reduce(
    (acc, order) => {
      if (order.orderingSessionId === currentSessionId) {
        acc.activeCount += 1;
      } else {
        acc.staleCount += 1;
      }
      return acc;
    },
    { activeCount: 0, staleCount: 0 }
  );

  return {
    groupId: String(normalizedGroup._id),
    groupName: normalizedGroup.name,
    dayOfWeek: normalizedGroup.dayOfWeek,
    isOpen: status.isOpen,
    statusMessage: status.message,
    sessionOpenAt: sessionOpenAt.toISOString(),
    currentSessionId,
    activeCount: summary.activeCount,
    staleCount: summary.staleCount,
  };
}

/**
 * GET /api/delivery-groups/ordering-status
 * Returns ordering window status for the current user's delivery group.
 * Admin/warehouse always get isOpen: true.
 */
router.get('/ordering-status', telegramAuth, async (req, res) => {
  const user = req.telegramUser;

  const transferEvent = Array.isArray(user.history)
    ? [...user.history].reverse().find((entry) =>
        entry.action === 'shop_changed'
        && entry.meta?.fromShop
        && entry.meta?.toShop
        && ['admin', 'warehouse'].includes(entry.byRole)
      )
    : null;
  const transferNote = transferEvent
    ? `Вас переміщено з магазину "${transferEvent.meta.fromShop}" на магазин "${transferEvent.meta.toShop}", ви робите замовлення на інший магазин. Якщо ви нічого не знаєте про це, зверніться до вашого менеджера або в групу в телеграмі!`
    : null;
  const transferNoteId = transferEvent
    ? `shop_changed:${transferEvent.at ? new Date(transferEvent.at).toISOString() : 'unknown'}`
    : null;
  const transferPayload = transferNote ? { note: transferNote, transferNoteId } : {};

  // Warehouse is always unrestricted. Admin without a shopId is also unrestricted.
  // Admin WITH a shopId goes through the same ordering window check as a seller.
  if (user.role === 'warehouse' || (user.role === 'admin' && !user.shopId)) {
    return res.json({ isOpen: true, ...transferPayload });
  }

  if (!user.shopId) {
    return res.json({
      isOpen: false,
      message: 'Вас не призначено до жодного магазину. Зверніться до адміністратора.',
      ...transferPayload,
    });
  }

  const shop = await Shop.findById(user.shopId).lean();
  if (!shop || !shop.deliveryGroupId) {
    return res.json({
      isOpen: false,
      message: 'Ваш магазин не прив\'язано до групи доставки. Зверніться до адміністратора.',
      ...transferPayload,
    });
  }

  const group = normalizeDeliveryGroup(await DeliveryGroup.findById(shop.deliveryGroupId).lean());
  if (!group) {
    return res.json({
      isOpen: false,
      message: 'Групу доставки не знайдено. Зверніться до адміністратора.',
      ...transferPayload,
    });
  }

  const schedule = await getOrderingSchedule();
  const status = isOrderingOpen(group.dayOfWeek, schedule);
  const window = getWindowDescription(group.dayOfWeek, schedule);
  const sessionOpenAt = getOrderingWindowOpenAt(group.dayOfWeek, schedule).toISOString();

  // "Я переглянув усі товари" — seed the button's state so a seller who already
  // pressed it (possibly on another device) sees the done state, not the button.
  // Best-effort: this is a cosmetic flag, it must never break the ordering window.
  let catalogReviewedAt = null;
  try {
    const sessionId = await getOrCreateSessionId(String(group._id), group.dayOfWeek, schedule);
    const mark = await CatalogReview.findOne(
      { sessionId, telegramId: String(user.telegramId) }, 'at',
    ).lean();
    catalogReviewedAt = mark?.at || null;
  } catch (e) {
    console.warn('[ordering-status] catalog review lookup failed:', e?.message || e);
  }

  return res.json({
    ...status,
    groupName: group.name,
    window,
    sessionOpenAt,
    catalogReviewedAt,
    ...transferPayload,
  });
});

/**
 * POST /api/delivery-groups/catalog-reviewed
 * The seller declares they walked the whole catalogue to the end in the CURRENT
 * ordering session. Informational only — nothing downstream gates on it; the
 * warehouse just wants to see who did and who didn't before picking starts.
 *
 * One-way and idempotent: the {sessionId, telegramId} unique index turns a second
 * press into a plain re-read, and there is no endpoint to clear the mark. It ages
 * out by itself when the next session starts (different sessionId).
 */
router.post('/catalog-reviewed', telegramAuth, asyncHandler(async (req, res) => {
  const user = req.telegramUser;
  if (!user.shopId) throw appError('no_shop');

  const shop = await Shop.findById(user.shopId).select('name deliveryGroupId').lean();
  if (!shop || !shop.deliveryGroupId) throw appError('group_not_found');

  const group = normalizeDeliveryGroup(await DeliveryGroup.findById(shop.deliveryGroupId).lean());
  if (!group) throw appError('group_not_found');

  const schedule = await getOrderingSchedule();
  const sessionId = await getOrCreateSessionId(String(group._id), group.dayOfWeek, schedule);

  const productCount = Number(req.body?.productCount) || 0;
  const doc = {
    sessionId,
    groupId: String(group._id),
    telegramId: String(user.telegramId),
    userName: [user.firstName, user.lastName].filter(Boolean).join(' ') || String(user.telegramId),
    shopId: String(user.shopId),
    shopName: shop.name || '',
    at: new Date(),
    productCount,
  };

  // $setOnInsert only: re-pressing must NOT move the timestamp the warehouse
  // already saw on the board.
  const saved = await CatalogReview.findOneAndUpdate(
    { sessionId, telegramId: doc.telegramId },
    { $setOnInsert: doc },
    { upsert: true, new: true, setDefaultsOnInsert: true },
  ).lean();

  // Nudge the picking board so the tick appears without waiting for a poll.
  try {
    const io = getIO();
    if (io) io.to(`picking_group_${String(group._id)}`).emit('shop_status_changed', { groupId: String(group._id) });
  } catch (e) {
    console.warn('[catalog-reviewed] socket emit failed:', e?.message || e);
  }

  res.json({ catalogReviewedAt: saved?.at || doc.at });
}));

router.get('/summary', async (req, res) => {
  const groups = await getAllDeliveryGroups();

  // Кількість активних магазинів по кожній групі
  const shopCounts = await Shop.aggregate([
    { $match: { isActive: true } },
    { $group: { _id: '$deliveryGroupId', count: { $sum: 1 } } },
  ]);
  const shopCountMap = Object.fromEntries(shopCounts.map(({ _id, count }) => [String(_id), count]));

  // Кількість продавців по кожній групі (через Shop)
  const sellerCounts = await User.aggregate([
    { $match: { role: 'seller', shopId: { $ne: null, $exists: true } } },
    { $lookup: { from: 'shops', localField: 'shopId', foreignField: '_id', as: 'shop' } },
    { $unwind: '$shop' },
    { $group: { _id: '$shop.deliveryGroupId', count: { $sum: 1 } } },
  ]);
  const sellerCountMap = Object.fromEntries(sellerCounts.map(({ _id, count }) => [String(_id), count]));

  const normalizedGroups = groups.map(normalizeDeliveryGroup);
  const result = normalizedGroups.map((g) => ({
    _id: g._id,
    name: g.name,
    dayOfWeek: g.dayOfWeek,
    shopCount: shopCountMap[String(g._id)] || 0,
    sellerCount: sellerCountMap[String(g._id)] || 0,
  }));
  result.sort((a, b) => {
    const orderA = a.dayOfWeek === 0 ? 7 : a.dayOfWeek;
    const orderB = b.dayOfWeek === 0 ? 7 : b.dayOfWeek;
    if (orderA !== orderB) return orderA - orderB;
    return String(a.name || '').localeCompare(String(b.name || ''));
  });
  res.json(result);
});

/**
 * GET /api/delivery-groups/:groupId/shop-status
 * Returns per-shop cart and ordered item counts for the current ordering session.
 */
router.get('/:groupId/shop-status', telegramAuth, requireTelegramRoles(['admin', 'warehouse']), asyncHandler(async (req, res) => {
  const group = normalizeDeliveryGroup(await DeliveryGroup.findById(req.params.groupId).lean());
  if (!group) throw appError('group_not_found');

  const schedule = await getOrderingSchedule();
  const status = isOrderingOpen(group.dayOfWeek, schedule);
  const currentSessionId = await getOrCreateSessionId(String(group._id), group.dayOfWeek, schedule);

  const shops = await Shop.find({ deliveryGroupId: String(group._id), isActive: true })
    .select('name cityId')
    .populate('cityId', 'name')
    .lean();

  const shopIds = shops.map((s) => s._id);
  // buyerSnapshot.shopId is stored as ObjectId in some paths and as a String in
  // others — match both forms so direct-add orders (null top-level shopId) are
  // counted. Without this, pre-start showed "0 orders" while the task builder
  // (which keys off buyerSnapshot.deliveryGroupId) still built tasks.
  const shopIdStrs = shopIds.map((id) => String(id));

  const orders = await Order.find({
    $or: [
      { shopId: { $in: shopIds } },
      { 'buyerSnapshot.shopId': { $in: shopIds } },
      { 'buyerSnapshot.shopId': { $in: shopIdStrs } },
    ],
    orderingSessionId: currentSessionId,
    status: { $in: ['new', 'in_progress'] },
  }).select('buyerSnapshot shopId buyerTelegramId items orderNumber _id createdAt history').lean();

  // Don't report stale orders while the ordering window is still open — during
  // that window the sessionId in DB may differ from currentSessionId (e.g. when a
  // test overrides the schedule), which causes false-positive "stale" warnings.
  const staleOrders = status.isOpen ? [] : await Order.find({
    'buyerSnapshot.deliveryGroupId': String(group._id),
    status: { $in: ['new', 'in_progress'] },
    orderingSessionId: { $ne: currentSessionId },
  }).select('buyerSnapshot buyerTelegramId items orderNumber _id createdAt orderingSessionId').lean();

  const sellers = await User.find({ role: { $in: ['seller', 'admin'] }, shopId: { $in: shopIds } })
    .select('shopId firstName lastName telegramId cartState role')
    .lean();
  // Collect ALL sellers per shop with cart status
  const sellersByShop = {};
  for (const seller of sellers) {
    const sid = String(seller.shopId);
    if (!sellersByShop[sid]) sellersByShop[sid] = [];
    const items = seller.cartState?.orderItems;
    const itemObj = items instanceof Map ? Object.fromEntries(items) : (items || {});
    sellersByShop[sid].push({
      name: [seller.firstName, seller.lastName].filter(Boolean).join(' ') || String(seller.telegramId),
      telegramId: String(seller.telegramId),
      role: seller.role,
      hasCart: Object.keys(itemObj).length > 0,
    });
  }

  // Build buyer name+role lookup from all unique buyerTelegramIds in orders
  const buyerTgIds = [...new Set([...orders, ...staleOrders].map((o) => o.buyerTelegramId).filter(Boolean))];
  const buyers = await User.find({ telegramId: { $in: buyerTgIds } })
    .select('telegramId firstName lastName role')
    .lean();
  const buyerInfoById = {};
  for (const b of buyers) {
    buyerInfoById[String(b.telegramId)] = {
      name: [b.firstName, b.lastName].filter(Boolean).join(' ') || b.telegramId,
      role: b.role,
    };
  }

  // Group orders by shopId for conflict detection
  const ordersByShop = {};
  const orderedByShop = {};
  for (const order of orders) {
    const shopId = String(order.shopId || order.buyerSnapshot?.shopId || '');
    if (!shopId) continue;
    if (!ordersByShop[shopId]) ordersByShop[shopId] = [];
    // Flag any order that was ever reassigned to a different shop (regardless of who did it).
    const reassignEntry = (order.history || []).slice().reverse().find((h) => h.action === 'shop_reassigned');
    const wasReassigned = !!reassignEntry;
    ordersByShop[shopId].push({
      orderId: String(order._id),
      orderNumber: order.orderNumber,
      buyerTelegramId: order.buyerTelegramId,
      buyerName: buyerInfoById[String(order.buyerTelegramId)]?.name || order.buyerTelegramId,
      buyerRole: buyerInfoById[String(order.buyerTelegramId)]?.role || 'seller',
      itemCount: (order.items || []).filter((i) => !i.cancelled && !i.skipped).length,
      createdAt: order.createdAt,
      wasReassigned,
      fromShopName: wasReassigned ? (reassignEntry?.meta?.from?.shopName || null) : null,
      reassignedByName: wasReassigned ? (reassignEntry?.byName || null) : null,
      reassignedByRole: wasReassigned ? (reassignEntry?.byRole || null) : null,
      reassignedByTelegramId: wasReassigned ? (reassignEntry?.by || null) : null,
      reassignedAt: wasReassigned ? (reassignEntry?.at || null) : null,
    });
    if (!orderedByShop[shopId]) orderedByShop[shopId] = new Set();
    for (const item of order.items || []) {
      if (item.productId && !item.cancelled && !item.skipped) orderedByShop[shopId].add(String(item.productId));
    }
  }

  // Resolve the CANONICAL identity of whoever moved each order here (the
  // "першоджерело" of the conflict) from the users collection — the history
  // byName can be a generic fallback ("Admin"), so prefer the real account.
  const actorIds = new Set();
  for (const list of Object.values(ordersByShop)) {
    for (const o of list) if (o.reassignedByTelegramId) actorIds.add(String(o.reassignedByTelegramId));
  }
  if (actorIds.size > 0) {
    const actors = await User.find({ telegramId: { $in: [...actorIds] } })
      .select('telegramId firstName lastName role').lean();
    const actorById = {};
    for (const a of actors) {
      actorById[String(a.telegramId)] = {
        name: [a.firstName, a.lastName].filter(Boolean).join(' ') || String(a.telegramId),
        role: a.role,
      };
    }
    for (const list of Object.values(ordersByShop)) {
      for (const o of list) {
        const a = o.reassignedByTelegramId && actorById[String(o.reassignedByTelegramId)];
        if (a) {
          o.reassignedByName = a.name;          // canonical First Last
          o.reassignedByRole = a.role;          // canonical role
        }
        // else: keep the history-recorded byName/byRole (actor account deleted)
      }
    }
  }

  // Build per-shop seller cart items map (cartState is now per-user, not per-shop)
  const cartItemsByShop = {};
  for (const seller of sellers) {
    const sid = String(seller.shopId);
    const items = seller.cartState?.orderItems;
    if (!items) continue;
    const itemObj = items instanceof Map ? Object.fromEntries(items) : items;
    cartItemsByShop[sid] = (cartItemsByShop[sid] || 0) + Object.keys(itemObj).length;
  }

  // Build set of telegramIds that placed an order per shop in this session
  const orderedBuyersByShop = {};
  for (const order of orders) {
    const sid = String(order.shopId || '');
    if (!sid || !order.buyerTelegramId) continue;
    if (!orderedBuyersByShop[sid]) orderedBuyersByShop[sid] = new Set();
    orderedBuyersByShop[sid].add(String(order.buyerTelegramId));
  }

  // "Переглянув усі товари" marks of THIS session, keyed by seller. Read once for
  // the whole group — the board renders it as a second tick next to «Замовив».
  const reviewMarks = await CatalogReview.find(
    { groupId: String(group._id), sessionId: currentSessionId }, 'telegramId at',
  ).lean();
  const reviewedAtByTelegramId = new Map(reviewMarks.map((r) => [String(r.telegramId), r.at]));

  const shopStatuses = shops.map((shop) => {
    const shopId = String(shop._id);
    const cartItemCount = cartItemsByShop[shopId] || 0;
    const shopOrders = ordersByShop[shopId] || [];
    const uniqueBuyers = new Set(shopOrders.map((o) => o.buyerTelegramId));
    const shopSellerObjs = sellersByShop[shopId] || [];
    const assignedStaff = shopSellerObjs.filter((s) => s.role === 'seller' || s.role === 'admin');
    const orderedBuyers = orderedBuyersByShop[shopId] || new Set();
    const sellersWithStatus = shopSellerObjs.map((s) => ({
      ...s,
      hasOrder: orderedBuyers.has(s.telegramId),
      catalogReviewedAt: reviewedAtByTelegramId.get(s.telegramId) || null,
    }));
    // hasConflict: 2+ separate buyers placed orders in this shop this session
    // hasMultipleSellers: 2+ seller/admin users are assigned to this shop.
    // hasSellerOrderMismatch: multiple assigned users but only some placed orders.
    const hasMultipleSellers = assignedStaff.length > 1;
    const sellersWithOrder = assignedStaff.filter((s) => orderedBuyers.has(s.telegramId));
    const hasSellerOrderMismatch = hasMultipleSellers && shopOrders.length > 0 && sellersWithOrder.length !== assignedStaff.length;
    return {
      shopId,
      shopName: shop.name,
      shopCity: shop.cityId?.name || '',
      sellers: sellersWithStatus,
      sellerName: sellersWithStatus.length > 0 ? sellersWithStatus.map((s) => s.name).join(', ') : null,
      sellerCount: sellersWithStatus.length,
      cartItemCount,
      orderedItemCount: orderedByShop[shopId]?.size || 0,
      orders: shopOrders,
      hasConflict: uniqueBuyers.size > 1,
      hasMultipleSellers,
      hasSellerOrderMismatch,
    };
  });

  // Sort by the shop's EARLIEST order creation time (oldest first) — same ordering
  // as the packing card, so a shop appears in the same relative position on both
  // screens. Shops with no orders this session sort to the bottom, by name.
  const earliestOrderAt = (shop) => {
    const times = (shop.orders || [])
      .map((o) => (o.createdAt ? new Date(o.createdAt).getTime() : null))
      .filter((t) => t !== null);
    return times.length ? Math.min(...times) : Infinity;
  };
  shopStatuses.sort((a, b) => {
    const ta = earliestOrderAt(a);
    const tb = earliestOrderAt(b);
    if (ta !== tb) return ta - tb;
    return String(a.shopName || '').localeCompare(String(b.shopName || ''), 'uk');
  });

  res.json({
    groupId: String(group._id),
    groupName: group.name,
    isOpen: status.isOpen,
    currentSessionId,
    viewerRole: req.telegramUser?.role || '',
    staleOrderCount: staleOrders.length,
    staleOrders: staleOrders.map((order) => ({
      orderId: String(order._id),
      orderNumber: order.orderNumber,
      buyerTelegramId: String(order.buyerTelegramId || ''),
      buyerName: buyerInfoById[String(order.buyerTelegramId)]?.name || order.buyerTelegramId,
      shopName: order.buyerSnapshot?.shopName || '—',
      shopCity: order.buyerSnapshot?.shopCity || '',
      itemCount: (order.items || []).filter((i) => !i.cancelled && !i.skipped).length,
      orderingSessionId: order.orderingSessionId || '',
      createdAt: order.createdAt,
    })),
    shops: shopStatuses,
  });
}));

router.get('/session-summaries', telegramAuth, requireTelegramRole('admin'), async (req, res) => {
  const groups = await getAllDeliveryGroups();
  const schedule = await getOrderingSchedule();
  const groupIds = groups.map((group) => String(group._id));

  const orders = await Order.find({
    'buyerSnapshot.deliveryGroupId': { $in: groupIds },
    status: { $in: ['new', 'in_progress'] },
  })
    .select('buyerSnapshot.deliveryGroupId orderingSessionId')
    .lean();

  const ordersByGroup = orders.reduce((acc, order) => {
    const groupId = String(order.buyerSnapshot.deliveryGroupId || '');
    if (!groupId) return acc;
    if (!acc[groupId]) acc[groupId] = [];
    acc[groupId].push(order);
    return acc;
  }, {});

  const summaries = await Promise.all(groups.map((group) => buildDeliveryGroupSessionSummary(group, schedule, ordersByGroup)));
  summaries.sort((a, b) => {
    const orderA = a.dayOfWeek === 0 ? 7 : a.dayOfWeek;
    const orderB = b.dayOfWeek === 0 ? 7 : b.dayOfWeek;
    if (orderA !== orderB) return orderA - orderB;
    return String(a.groupName || '').localeCompare(String(b.groupName || ''));
  });
  res.json(summaries);
});

router.post('/:id/close-ordering-session', telegramAuth, requireTelegramRole('admin'), asyncHandler(async (req, res) => {
  const group = await DeliveryGroup.findById(req.params.id).lean();
  if (!group) throw appError('group_not_found');

  const admin = req.telegramUser || {};
  const adminActor = {
    by: String(admin.telegramId || ''),
    byName: [admin.firstName, admin.lastName].filter(Boolean).join(' '),
  };

  const schedule = await getOrderingSchedule();
  const status = isOrderingOpen(group.dayOfWeek, schedule);
  const currentSessionId = await getOrCreateSessionId(String(group._id), group.dayOfWeek, schedule);

  // HARD RULE: once the warehouse has taken an order into the picking pipeline
  // (PickingTask pending/locked/completed) it is being physically packed. You
  // must NOT expire it just because the ordering session is being moved/closed —
  // that would silently lose a real, packed order. Exclude every such order.
  const pipelineTasks = await PickingTask.find(
    { status: { $in: ['pending', 'locked', 'completed'] } },
    'items.orderId',
  ).lean();
  const protectedOrderIds = [];
  for (const t of pipelineTasks) {
    for (const it of t.items || []) {
      if (it.orderId) protectedOrderIds.push(it.orderId);
    }
  }

  const staleOrderFilter = {
    'buyerSnapshot.deliveryGroupId': String(group._id),
    status: { $in: ['new', 'in_progress'] },
  };
  if (status.isOpen) {
    staleOrderFilter.orderingSessionId = { $ne: currentSessionId };
  }
  if (protectedOrderIds.length > 0) {
    staleOrderFilter._id = { $nin: protectedOrderIds };
  }

  // Transaction so a double-click / concurrent close cannot double-process.
  let expiredCount = 0;
  const session = await mongoose.connection.startSession();
  try {
    await session.withTransaction(async () => {
      const result = await Order.updateMany(
        staleOrderFilter, { status: 'expired' }, { session },
      );
      expiredCount = result.modifiedCount ?? result.nModified ?? 0;
    });
  } finally {
    session.endSession();
  }

  // Log "Закінчилась" on the session timeline — but only when the window for
  // THIS session is actually closing. If the admin clicks "close" while the
  // window is still open (intent = "just clean up stale orders from a previous
  // cycle"), we'd otherwise stamp the current cycle's session with a misleading
  // window-closed event even though its window remains open.
  if (!status.isOpen) {
    try {
      await pushSessionEvent(currentSessionId, {
        type: 'window_closed',
        ...adminActor,
        meta: { expiredCount },
      });
    } catch (e) {
      console.warn('[deliveryGroups/close-ordering-session] event push failed:', e.message);
    }
  }

  res.json({
    message: expiredCount > 0
      ? `Старі замовлення з попередньої сесії закрито: ${expiredCount}.`
      : 'Старих замовлень для закриття не знайдено.',
    expiredCount,
  });
}));

router.get('/', async (req, res) => {
  const groups = await getAllDeliveryGroups();
  const normalizedGroups = groups.map(normalizeDeliveryGroup);
  normalizedGroups.sort((a, b) => {
    const orderA = a.dayOfWeek === 0 ? 7 : a.dayOfWeek;
    const orderB = b.dayOfWeek === 0 ? 7 : b.dayOfWeek;
    if (orderA !== orderB) return orderA - orderB;
    return String(a.name || '').localeCompare(String(b.name || ''));
  });
  const schedule = await getOrderingSchedule();

  // Flag groups whose ordering session is currently CLOSED but still have active orders.
  // This covers any case — seller switched shop, admin moved order, whatever.
  // Orders in an OPEN session are resolved (normal or conflict), no badge needed.
  const closedGroupIds = [];
  for (const g of normalizedGroups) {
    const { isOpen } = isOrderingOpen(g.dayOfWeek, schedule);
    if (!isOpen) {
      closedGroupIds.push(String(g._id));
    }
  }
  const problematicByGroup = {};
  if (closedGroupIds.length > 0) {
    const ordersInClosedGroups = await Order.find({
      'buyerSnapshot.deliveryGroupId': { $in: closedGroupIds },
      status: { $in: ['new', 'in_progress'] },
    }).select('buyerSnapshot.deliveryGroupId').lean();
    for (const order of ordersInClosedGroups) {
      const groupId = order?.buyerSnapshot?.deliveryGroupId ? String(order.buyerSnapshot.deliveryGroupId) : '';
      if (groupId) problematicByGroup[groupId] = true;
    }
  }

  const [shopCounts, sellerCounts] = await Promise.all([
    Shop.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$deliveryGroupId', count: { $sum: 1 } } },
    ]),
    User.aggregate([
      { $match: { role: 'seller', shopId: { $ne: null, $exists: true } } },
      { $lookup: { from: 'shops', localField: 'shopId', foreignField: '_id', as: 'shop' } },
      { $unwind: '$shop' },
      { $group: { _id: '$shop.deliveryGroupId', count: { $sum: 1 } } },
    ]),
  ]);
  const shopCountMap = Object.fromEntries(shopCounts.map(({ _id, count }) => [String(_id), count]));
  const sellerCountMap = Object.fromEntries(sellerCounts.map(({ _id, count }) => [String(_id), count]));

  const result = normalizedGroups.map((g) => ({
    ...g,
    isOpen: isOrderingOpen(g.dayOfWeek, schedule).isOpen,
    shopCount: shopCountMap[String(g._id)] || 0,
    sellerCount: sellerCountMap[String(g._id)] || 0,
    hasRelocatedOrders: !!problematicByGroup[String(g._id)],
  }));
  res.json(result);
});

router.post('/', telegramAuth, requireTelegramRole('admin'), asyncHandler(async (req, res) => {
  const { name, dayOfWeek } = req.body;
  const trimmedName = typeof name === 'string' ? name.trim() : '';
  if (!trimmedName || dayOfWeek === undefined) throw appError('group_name_or_day_required');

  const group = new DeliveryGroup({ name: trimmedName, dayOfWeek });
  await group.save();
  await cache.invalidate(cache.KEYS.DELIVERY_GROUPS);
  await invalidateDeliveryGroup(group._id);
  res.status(201).json(group);
}));

router.patch('/:id', telegramAuth, requireTelegramRole('admin'), asyncHandler(async (req, res) => {
  const group = await DeliveryGroup.findById(req.params.id);
  if (!group) throw appError('group_not_found');

  const admin = req.telegramUser || {};
  const adminActor = {
    by: String(admin.telegramId || ''),
    byName: [admin.firstName, admin.lastName].filter(Boolean).join(' '),
  };

  const { name, dayOfWeek } = req.body;

  // Guard: dayOfWeek is the key the ordering/picking SESSION identity is derived
  // from (getOpenDateWarsaw → OrderingSession {groupId, openDate}). Changing it
  // mid-cycle would re-key "current session": orders placed before the change keep
  // their old orderingSessionId and fall out of the new current session — stranded,
  // not picked. So we refuse the change while a cycle is in progress. Changing it
  // once the cycle is over naturally applies to the NEXT session.
  const dayIsChanging = dayOfWeek !== undefined && Number(dayOfWeek) !== Number(group.dayOfWeek);
  let oldSessionId = null;
  let fromDay = null;
  let toDay = null;
  if (dayIsChanging) {
    const schedule = await getOrderingSchedule();
    const groupIdStr = String(group._id);

    // 1) ordering window currently open for this group?
    const { isOpen } = isOrderingOpen(group.dayOfWeek, schedule);

    // 2) active orders in the CURRENT session, or 3) active picking tasks?
    // "Active" must mean "has something left to strand": an order whose every
    // position was cancelled/skipped carries nothing into the next session, so it
    // must NOT veto the change. Status alone was the wrong test — an order the
    // seller emptied right after placing it stayed `new` forever and blocked the
    // day change permanently, while every board (which counts live positions)
    // reported «Замовлень немає». /upsert-item + /remove-item now close such
    // orders on the spot; this $elemMatch is the guard's own safety net.
    const currentSessionId = await getOrCreateSessionId(groupIdStr, group.dayOfWeek, schedule);
    const [activeOrder, activeTask] = await Promise.all([
      Order.exists({
        'buyerSnapshot.deliveryGroupId': groupIdStr,
        orderingSessionId: currentSessionId,
        status: { $in: ['new', 'in_progress'] },
        items: { $elemMatch: { cancelled: { $ne: true }, skipped: { $ne: true } } },
      }),
      PickingTask.exists({ deliveryGroupId: groupIdStr, status: { $in: ['pending', 'locked'] } }),
    ]);

    if (isOpen || activeOrder || activeTask) {
      const reason = isOpen ? 'вікно замовлень відкрите'
        : activeOrder ? 'є активні замовлення в поточній сесії'
        : 'триває збирання';
      throw appError('group_day_change_session_active', { reason });
    }

    // Resolve the soon-to-be-orphaned session BEFORE we mutate dayOfWeek — the
    // session identity is derived from it, so reading after the save would point
    // at the new day's session and "Перенесена" would land on the wrong doc.
    // The guard above already materialised this session via getOrCreateSessionId,
    // so reusing the id is free (no extra round-trip).
    oldSessionId = currentSessionId;
    fromDay = Number(group.dayOfWeek);
    toDay = Number(dayOfWeek);
  }

  if (name !== undefined) {
    const trimmedName = String(name).trim();
    if (!trimmedName) throw appError('group_name_or_day_required');
    group.name = trimmedName;
  }
  if (dayOfWeek !== undefined) group.dayOfWeek = dayOfWeek;

  await group.save();
  await cache.invalidate(cache.KEYS.DELIVERY_GROUPS);
  await invalidateDeliveryGroup(group._id);

  if (dayIsChanging && oldSessionId) {
    try {
      await pushSessionEvent(oldSessionId, {
        type: 'rescheduled',
        ...adminActor,
        meta: { fromDay, toDay },
      });
    } catch (e) {
      console.warn('[deliveryGroups/PATCH] rescheduled event push failed:', e.message);
    }
  }
  res.json(group);
}));

router.delete('/:id', telegramAuth, requireTelegramRole('admin'), asyncHandler(async (req, res) => {
  // Check + delete in a single transaction so that a magazin or active order
  // created between the count and findByIdAndDelete cannot leave an orphan
  // reference behind.
  const session = await mongoose.connection.startSession();
  try {
    let result;
    await session.withTransaction(async () => {
      const group = await DeliveryGroup.findById(req.params.id).session(session);
      if (!group) throw appError('group_not_found');

      const shopCount = await Shop.countDocuments({
        deliveryGroupId: String(group._id),
      }).session(session);
      if (shopCount > 0) throw appError('group_has_shops', { shopCount });

      const activeOrders = await Order.countDocuments({
        'buyerSnapshot.deliveryGroupId': String(group._id),
        status: { $in: ['new', 'in_progress'] },
      }).session(session);
      if (activeOrders > 0) throw appError('group_has_active_orders', { activeOrders });

      await DeliveryGroup.deleteOne({ _id: group._id }, { session });
      result = { message: 'Групу видалено', _groupId: String(group._id) };
    });
    await cache.invalidate(cache.KEYS.DELIVERY_GROUPS);
    if (result?._groupId) {
      await invalidateDeliveryGroup(result._groupId);
      delete result._groupId;
    }
    return res.json(result);
  } finally {
    session.endSession();
  }
}));

/**
 * POST /api/delivery-groups/:id/broadcast
 * Send all active products to all members of the specified delivery group.
 */
/*
router.post('/:id/broadcast', telegramAuth, requireTelegramRole('admin'), async (req, res) => {
  const group = await DeliveryGroup.findById(req.params.id);
  if (!group) return res.status(404).json({ error: 'Group not found' });

  if (!group.members?.length) {
    return res.status(400).json({ error: 'Група не має учасників' });
  }

  try {
    const { startBroadcast } = require('../broadcast');
    const result = await startBroadcast({
      productFilter: { status: 'active' },
      recipientIds: group.members,
      addLabels: true,
    });
    res.json({ message: `Розсилку розпочато для групи "${group.name}"`, ...result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
*/

module.exports = router;
