const express = require('express');
const crypto = require('crypto');
const mongoose = require('mongoose');
const Busboy = require('busboy');
const { S3Client, PutObjectCommand, HeadBucketCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const { buildImageVariants } = require('../utils/imageService');
const { requireTelegramRoles } = require('../middleware/telegramAuth');
const Receipt = require('../models/Receipt');
const ReceiptItem = require('../models/ReceiptItem');
const Product = require('../models/Product');
const ShopProduct = require('../models/ShopProduct');
const User = require('../models/User');
const Order = require('../models/Order');
const Block = require('../models/Block');
const ReceiptItemLog = require('../models/ReceiptItemLog');
const DeliveryGroup = require('../models/DeliveryGroup');
const Shop = require('../models/Shop');
const Counter = require('../models/Counter');
const { getIO } = require('../socket');
const { upsertShopOwnedFromReceiptItem, syncMirror } = require('../utils/upsertShopProduct');
const { embedShopProductAsync } = require('../utils/shopProductEmbedding');
const { embedProductAsync } = require('../utils/productEmbedding');
const { getGeminiStatus } = require('../geminiClient');
const { describeImageUrl } = require('../utils/productDescribe');
const { appError, asyncHandler } = require('../utils/errors');
const {
  assertCanEditItem,
  assertCanDeleteItem,
  assertCanConfirmItem,
  assertItemReadyToConfirm,
  resolveStructure,
  deriveSplit,
} = require('../utils/receiptPermissions');

const staffOnly = requireTelegramRoles(['admin', 'warehouse']);

const FIELD_LABELS = {
  name: 'Назва',
  totalQty: 'Загальна к-сть',
  transitQty: 'В магазини',
  shelfQty: 'На склад',
  price: 'Ціна',
  qtyPerPackage: 'В упаковці',
  qtyPerShop: 'На магазин',
  barcode: 'Штрихкод',
  photoUrl: 'Фото',
};

async function ensureReceiptItemProduct(item, session) {
  // `destination: 'shops'` goods never hit the warehouse, so they create NO
  // warehouse Product and apply NO shelf stock. Their shop-catalog routing
  // (shop-owned ShopProduct for new items, or transit marker for items linked
  // to an existing warehouse product) is handled by the confirm/commit caller,
  // outside the stock transaction. Returning null here keeps stock untouched.
  if ((item.destination || 'shelf') === 'shops') return null;

  let product = null;
  if (item.existingProductId) {
    product = await Product.findById(item.existingProductId).session(session);
    if (product) {
      if (item.shelfQty > 0 && !item.stockApplied) {
        product.quantity += item.shelfQty;
      }
      if (item.price !== null) {
        product.price = item.price;
      }
      if (item.qtyPerPackage) {
        product.quantityPerPackage = item.qtyPerPackage;
      }
      // INVARIANT: status follows BLOCK membership, not receipt confirm. A received
      // product stays 'pending' (in Надходження) until it is physically placed into
      // a block — only then does block-add flip it to 'active'. shelvedAt still
      // records the receive moment for the "Нові товари" recency split.
      if (item.shelfQty > 0 && !product.shelvedAt) product.shelvedAt = new Date();
      await product.save({ session });
      if (item.shelfQty > 0 && !item.stockApplied) {
        item.stockApplied = true;
        await item.save({ session });
      }
      return product;
    }
  }

  if (item.createdProductId) {
    product = await Product.findById(item.createdProductId).session(session);
    if (product) {
      if (item.shelfQty > 0 && !item.stockApplied) {
        product.quantity = item.shelfQty;
      }
      if (item.price !== null) {
        product.price = item.price;
      }
      if (item.qtyPerPackage) {
        product.quantityPerPackage = item.qtyPerPackage;
      }
      // INVARIANT: status follows BLOCK membership, not receipt confirm. A received
      // product stays 'pending' (in Надходження) until it is physically placed into
      // a block — only then does block-add flip it to 'active'. shelvedAt still
      // records the receive moment for the "Нові товари" recency split.
      if (item.shelfQty > 0 && !product.shelvedAt) product.shelvedAt = new Date();
      await product.save({ session });
      if (item.shelfQty > 0 && !item.stockApplied) {
        item.stockApplied = true;
        await item.save({ session });
      }
      return product;
    }
  }

  // Filter archived products: they keep orderNumber:0 (archiveProduct), so excluding
  // them matches the other allocation paths (products.js add/receive) and guards
  // against any future archived doc that retains a high number poisoning the max.
  const maxProduct = await Product.findOne({ status: { $ne: 'archived' } }, 'orderNumber').sort({ orderNumber: -1 }).session(session).lean();
  const nextOrderNumber = (maxProduct?.orderNumber ?? 0) + 1;
  const pm = item.photoMeta || {};
  const labelPositions = {};
  if (pm.commentPos) { labelPositions.commentX = pm.commentPos.x; labelPositions.commentY = pm.commentPos.y; }
  if (pm.pricePos)   { labelPositions.priceX   = pm.pricePos.x;   labelPositions.priceY   = pm.pricePos.y; }
  if (pm.qtyPos)     { labelPositions.qtyX     = pm.qtyPos.x;     labelPositions.qtyY     = pm.qtyPos.y; }

  product = new Product({
    orderNumber: nextOrderNumber,
    price: item.price ?? 0,
    quantity: item.shelfQty,
    warehouse: '',
    category: '',
    name: item.name || '',
    brand: item.name || '',
    model: '',
    // New receipt product is NOT in a block yet → 'pending' (Надходження). It
    // becomes 'active' only when placed into a block. shelvedAt records receive time.
    status: 'pending',
    shelvedAt: item.shelfQty > 0 ? new Date() : null,
    source: 'receipt',
    imageUrls: [item.photoUrl],
    imageNames: [item.photoName],
    originalImageUrl: item.originalPhotoUrl || '',
    labelPositions,
    barcode: item.barcode || '',
    quantityPerPackage: item.qtyPerPackage || 0,
    aiDescription: item.aiDescription || '',
  });

  try {
    await product.save({ session });
  } catch (err) {
    if (err.code === 11000) {
      if (err.keyPattern?.barcode) throw appError('product_barcode_duplicate');
      // Two concurrent confirms both read the same max orderNumber and raced for
      // max+1. E11000 is NOT a TransientTransactionError, so withTransaction does
      // NOT auto-retry it — surface a clear "try again" instead of the generic
      // duplicate_key the central handler would otherwise emit.
      if (err.keyPattern?.orderNumber) throw appError('product_order_number_conflict');
    }
    throw err;
  }
  item.createdProductId = product._id;
  // Stock is applied here via the new product's initial `quantity`.
  if (item.shelfQty > 0) item.stockApplied = true;
  await item.save({ session });
  return product;
}

function getActor(req) {
  const u = req.telegramUser || {};
  return {
    telegramId: String(u.telegramId || ''),
    firstName: u.firstName || '',
    lastName: u.lastName || '',
  };
}

const s3Client = new S3Client({
  region: process.env.R2_REGION || 'auto',
  endpoint: process.env.R2_ENDPOINT,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
  },
  forcePathStyle: true,
});

(async () => {
  try {
    await s3Client.send(new HeadBucketCommand({ Bucket: process.env.R2_BUCKET_NAME }));
    console.log('Cloudflare R2 bucket OK');
  } catch (err) {
    console.error('R2 bucket check failed:', err.message);
  }
})();

function parseMultipart(req) {
  return new Promise((resolve, reject) => {
    const busboy = Busboy({ headers: req.headers, limits: { fileSize: 10 * 1024 * 1024 } });
    const fields = {};
    const files = [];

    busboy.on('field', (name, val) => { fields[name] = val; });
    busboy.on('file', (name, stream, info) => {
      const allowed = /^image\/(jpeg|png|webp|gif)$/i;
      if (!allowed.test(info.mimeType)) {
        stream.resume();
        return;
      }

      const chunks = [];
      stream.on('data', (chunk) => chunks.push(chunk));
      stream.on('end', () => {
        if (stream.truncated) {
          return reject(new Error('File size limit exceeded'));
        }
        files.push({ field: name, buffer: Buffer.concat(chunks), originalname: info.filename, mimetype: info.mimeType });
      });
    });

    busboy.on('close', () => resolve({ fields, files }));
    busboy.on('error', reject);
    req.pipe(busboy);
  });
}

// Single image processing path — sharp normalises orientation, produces main
// (<folder>/<uuid>.jpg) and a 240px thumbnail (thumbs/<uuid>.jpg) in one call.
// The `filename` and `contentType` parameters are kept for backwards-compatible
// call sites but are now ignored (sharp always outputs JPEG with a fresh UUID).
async function uploadToR2(fileBuffer, _filename, _contentType, folder = 'products') {
  const { filename, main, thumb } = await buildImageVariants(fileBuffer);
  await Promise.all([
    s3Client.send(new PutObjectCommand({
      Bucket: process.env.R2_BUCKET_NAME,
      Key: `${folder}/${filename}`,
      Body: main,
      ContentType: 'image/jpeg',
    })),
    s3Client.send(new PutObjectCommand({
      Bucket: process.env.R2_BUCKET_NAME,
      Key: `thumbs/${filename}`,
      Body: thumb,
      ContentType: 'image/jpeg',
    })),
  ]);
  return filename;
}

/** Build the public URL for an uploaded object in the given folder. */
function r2Url(folder, filename) {
  return `${process.env.R2_PUBLIC_URL.replace(/\/$/, '')}/${folder}/${filename}`;
}

// Sanitize a client-supplied R2 filename (the photo/original are uploaded direct
// to R2 by the browser; only the filename comes back). Rejects path traversal.
function safeUploadName(v) {
  const s = String(v || '').trim();
  return /^[a-zA-Z0-9._-]+\.(jpg|jpeg|png|webp)$/i.test(s) ? s : '';
}

/** Upload up to `max` defect-evidence photos to the defects/ folder. */
async function uploadDefectPhotos(parsedFiles, max = 3) {
  const defectFiles = (parsedFiles || []).filter((f) => f.field === 'defectPhoto').slice(0, max);
  const urls = [];
  for (const f of defectFiles) {
    const fn = await uploadToR2(f.buffer, f.originalname, f.mimetype, 'defects');
    urls.push(r2Url('defects', fn));
  }
  return urls;
}

/**
 * Build defects/ public URLs from client-supplied filenames. Defect photos are
 * now uploaded straight to R2 by the browser (defects/<f> + thumbs/<f>); only
 * their sanitized filenames reach us. Bad/forged names are dropped.
 */
function defectUrlsFromFilenames(rawField, max = 3) {
  const names = safeParseArray(rawField) || [];
  return names.map(safeUploadName).filter(Boolean).slice(0, max).map((fn) => r2Url('defects', fn));
}

/** Parses a form-field string to a safe non-negative integer. Returns fallback on NaN/negative/missing. */
function parseIntField(val, fallback = 0) {
  const n = Math.trunc(Number(val));
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}

/**
 * Parses a form-field string to a finite number (price, qtyPerPackage).
 * Returns null if the field is absent or empty; throws validation_failed if
 * the value is present but not a finite number (NaN, Infinity, text).
 */
function parseNumberField(val, fieldName) {
  if (val === undefined || val === null || val === '') return null;
  const n = Number(val);
  if (!Number.isFinite(n)) throw appError('validation_failed', { field: fieldName });
  return n;
}

/**
 * Best-effort R2 cleanup for defect photos that were uploaded before a
 * transaction that subsequently failed. Deletes both the defects/ object
 * and its thumbs/ companion (created by buildImageVariants).  Never throws.
 */
async function cleanupDefectPhotos(urls) {
  if (!urls || urls.length === 0) return;
  const base = (process.env.R2_PUBLIC_URL || '').replace(/\/$/, '') + '/';
  const keys = urls.flatMap((url) => {
    const key = url.startsWith(base) ? url.slice(base.length) : null;
    if (!key) return [];
    return [key, key.replace(/^defects\//, 'thumbs/')];
  });
  await Promise.allSettled(
    keys.map((k) => s3Client.send(new DeleteObjectCommand({ Bucket: process.env.R2_BUCKET_NAME, Key: k }))),
  ).catch(() => {});
}

/** Parses a JSON array field. Returns [] when absent, string[] on success, null on bad JSON. */
function safeParseArray(val) {
  if (!val) return [];
  try {
    const arr = JSON.parse(val);
    return Array.isArray(arr) ? arr.map(String).filter(Boolean) : null;
  } catch {
    return null;
  }
}

/** Parses a JSON object field. Returns null when absent, object on success, undefined on bad JSON. */
function safeParseObject(val) {
  if (val === undefined || val === '' || val === null) return null;
  try {
    const obj = JSON.parse(val);
    return obj && typeof obj === 'object' && !Array.isArray(obj) ? obj : undefined;
  } catch {
    return undefined;
  }
}

const router = express.Router();

router.get('/', staffOnly, asyncHandler(async (req, res) => {
  const statusFilter = req.query.status;
  const page     = Math.max(1, parseInt(req.query.page) || 1);
  const pageSize = Math.min(100, Math.max(1, parseInt(req.query.pageSize) || 20));

  const query = {};
  if (statusFilter) query.status = statusFilter;

  // Date range filter on createdAt. dateTo is treated as inclusive end-of-day.
  const createdAt = {};
  const fromMs = Date.parse(req.query.dateFrom || '');
  const toMs = Date.parse(req.query.dateTo || '');
  if (Number.isFinite(fromMs)) createdAt.$gte = new Date(fromMs);
  if (Number.isFinite(toMs)) createdAt.$lte = new Date(toMs + 24 * 60 * 60 * 1000 - 1);
  if (Object.keys(createdAt).length) query.createdAt = createdAt;

  // Free-text search by receipt number (escaped, case-insensitive).
  const q = String(req.query.q || '').trim();
  if (q) {
    const escaped = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    query.receiptNumber = { $regex: escaped, $options: 'i' };
  }

  const SORTS = {
    date_desc: { createdAt: -1 },
    date_asc: { createdAt: 1 },
    number_desc: { receiptNumber: -1 },
    number_asc: { receiptNumber: 1 },
  };
  const sortSpec = SORTS[req.query.sort] || SORTS.date_desc;

  const [total, receipts] = await Promise.all([
    Receipt.countDocuments(query),
    Receipt.find(query)
      .sort(sortSpec)
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .lean(),
  ]);

  // Batch count items (one aggregate instead of N queries)
  const receiptIds = receipts.map((r) => r._id);
  const counts = await ReceiptItem.aggregate([
    { $match: { receiptId: { $in: receiptIds } } },
    { $group: { _id: '$receiptId', count: { $sum: 1 } } },
  ]);
  const countMap = new Map(counts.map((c) => [String(c._id), c.count]));
  const receiptsWithCounts = receipts.map((r) => ({ ...r, itemsCount: countMap.get(String(r._id)) || 0 }));

  res.json({
    receipts: receiptsWithCounts,
    total,
    page,
    pageSize,
    pageCount: Math.max(1, Math.ceil(total / pageSize)),
  });
}));

router.get('/:id', staffOnly, asyncHandler(async (req, res) => {
  const receipt = await Receipt.findById(req.params.id).lean();
  if (!receipt) throw appError('receipt_not_found');
  res.json(receipt);
}));

router.delete('/:id', staffOnly, asyncHandler(async (req, res) => {
  const receipt = await Receipt.findById(req.params.id);
  if (!receipt) throw appError('receipt_not_found');
  if (receipt.status !== 'draft') throw appError('receipt_only_draft_delete');

  const itemCount = await ReceiptItem.countDocuments({ receiptId: receipt._id });
  if (itemCount > 0) throw appError('receipt_only_empty_delete');

  await receipt.deleteOne();
  res.json({ message: 'Receipt deleted' });
}));

async function getNextReceiptNumber() {
  const counter = await Counter.findOneAndUpdate(
    { name: 'receiptNumber' },
    { $inc: { seq: 1 } },
    { upsert: true, new: true },
  );
  return `REC-${String(counter.seq).padStart(4, '0')}`;
}

router.post('/', staffOnly, asyncHandler(async (req, res) => {
  const receiptNumber = await getNextReceiptNumber();
  const receipt = new Receipt({
    receiptNumber,
    status: 'draft',
    createdBy: req.user.telegramId,
  });
  try {
    await receipt.save();
  } catch (err) {
    if (err.code === 11000) throw appError('receipt_number_exists');
    throw err;
  }
  ReceiptItemLog.create({
    receiptId: receipt._id,
    itemName: receipt.receiptNumber,
    action: 'receipt_create',
    actor: getActor(req),
  }).catch((e) => console.error('[ReceiptItemLog] receipt_create error:', e));
  res.status(201).json(receipt);
}));

router.post('/:id/items', staffOnly, asyncHandler(async (req, res) => {
  const receipt = await Receipt.findById(req.params.id);
  if (!receipt) throw appError('receipt_not_found');
  if (receipt.status !== 'draft') throw appError('receipt_already_completed');

  if (!req.is('multipart/form-data')) throw appError('receipt_multipart_required');

  const parsed = await parseMultipart(req);
  // Main photo + clean original are uploaded straight to R2 by the browser; only
  // their filenames arrive here. (Defect photos still come as multipart files.)
  const photoFilename    = safeUploadName(parsed.fields.photoFilename);
  const originalFilename = safeUploadName(parsed.fields.originalFilename);
  const photoMeta = safeParseObject(parsed.fields.photoMeta) || null;
  const existingProductId = parsed.fields.existingProductId ? String(parsed.fields.existingProductId).trim() : null;
  const isWarehousePending = parsed.fields.warehousePending === 'true';
  const deliveryGroupIds = safeParseArray(parsed.fields.deliveryGroupIds);
  if (deliveryGroupIds === null) throw appError('receipt_invalid_delivery_groups');
  if (deliveryGroupIds.length > 0) {
    const existingCount = await DeliveryGroup.countDocuments({ _id: { $in: deliveryGroupIds } });
    if (existingCount !== deliveryGroupIds.length) throw appError('receipt_delivery_groups_missing');
  }
  const qtyPerShop = parseIntField(parsed.fields.qtyPerShop);

  if (!photoFilename && !existingProductId) throw appError('receipt_photo_required');

  // Destination is the UI-level choice; it derives the shelf/transit split.
  const destination = String(parsed.fields.destination || 'shelf');
  if (!['shelf', 'shops'].includes(destination)) throw appError('receipt_destination_required');
  // NOTE: destination is currently just a bookkeeping marker — the delivery-group
  // / transit UI was removed for now, so we no longer hard-require groups here.

  // КРИТИЧНЕ ПРАВИЛО (спека дозамовлень §4): галочка «Дозамовлення» дійсна лише
  // для товару, що йде НА СКЛАД. Це не дублювання клієнтської валідації заради
  // акуратності — старий клієнт або ручний POST не мають змоги створити
  // дозамовлення для destination='shops' (§21, §22 тест 3).
  const supplementOffer = parsed.fields.supplementOffer === 'true' && destination === 'shelf';

  // Quantity: either a manual total ('direct') or computed from a structure.
  const rawStructure = safeParseObject(parsed.fields.structure);
  if (rawStructure === undefined) throw appError('receipt_structure_invalid');
  const manualTotalQty = parseIntField(parsed.fields.totalQty);
  const { totalQty, structure } = resolveStructure(rawStructure, manualTotalQty);

  const { shelfQty, transitQty } = deriveSplit(destination, totalQty);

  let photoUrl;
  let photoName;
  let originalPhotoUrl = '';
  if (photoFilename) {
    photoUrl  = r2Url('products', photoFilename);
    photoName = photoFilename;
  }
  if (originalFilename) {
    // CLEAN original lives in originals/ — it's the embedding/describe source and
    // must never be the price/quantity-labelled photo (which is in products/).
    originalPhotoUrl = r2Url('originals', originalFilename);
  }
  // Prefer client-direct R2 filenames; fall back to legacy multipart bytes.
  const defectFilenameUrls = defectUrlsFromFilenames(parsed.fields.defectFilenames);
  const defectPhotoUrls = defectFilenameUrls.length
    ? defectFilenameUrls
    : await uploadDefectPhotos(parsed.files);
  // SAVE-tier rule: a line can be parked with just photo + arrived qty (no
  // price yet). Price / qtyPerPackage are only required later to CONFIRM.
  const notes = String(parsed.fields.notes || '').trim();

  // Pull photo from existingProduct if item has no photo
  if (!photoUrl && existingProductId) {
    const existingProduct = await Product.findById(existingProductId).lean();
    if (existingProduct) {
      photoUrl = existingProduct.imageUrls?.[0] || existingProduct.localImageUrl || '';
      photoName = existingProduct.imageNames?.[0] || existingProduct.imageUrls?.[0] || 'photo.jpg';
    }
  }

  const receiptItem = new ReceiptItem({
    receiptId: receipt._id,
    createdBy: String(req.user.telegramId),
    status: 'draft',
    destination,
    structure,
    photoUrl: photoUrl || '',
    photoName: photoName || '',
    originalPhotoUrl,
    photoMeta: photoMeta && typeof photoMeta === 'object'
      ? {
          comment: String(photoMeta.comment || ''),
          commentPos: {
            x: Number(photoMeta?.commentPos?.x) || 0.5,
            y: Number(photoMeta?.commentPos?.y) || 0.5,
          },
          pricePos: photoMeta.pricePos || null,
          qtyPos:   photoMeta.qtyPos || null,
        }
      : undefined,
    totalQty,
    notes,
    defectPhotoUrls,
    transitQty: transitQty || 0,
    deliveryGroupIds: Array.isArray(deliveryGroupIds) ? deliveryGroupIds : [],
    qtyPerShop,
    shelfQty,
    name: String(parsed.fields.name || '').trim(),
    price: parseNumberField(parsed.fields.price, 'price'),
    qtyPerPackage: parseNumberField(parsed.fields.qtyPerPackage, 'qtyPerPackage'),
    barcode: String(parsed.fields.barcode || '').trim(),
    existingProductId: existingProductId || null,
    warehousePending: isWarehousePending,
    supplementOffer,
  });

  // Save item AND re-check receipt.status='draft' in the SAME transaction so that
  // a concurrent commit (which CAS-flips status to 'completed') will either run
  // before us (we abort with 409) or run after us (it sees our changes).
  // Аналогічний захист є в PATCH і DELETE — тепер і тут.
  const addItemSession = await mongoose.connection.startSession();
  try {
    await addItemSession.withTransaction(async () => {
      const liveReceipt = await Receipt.findOne(
        { _id: req.params.id, status: 'draft' },
        '_id status',
      ).session(addItemSession);
      if (!liveReceipt) throw appError('receipt_already_completed');
      await receiptItem.save({ session: addItemSession });
    });
  } catch (txErr) {
    // Transaction failed after defect photos were already uploaded — clean them up.
    cleanupDefectPhotos(defectPhotoUrls).catch(() => {});
    throw txErr;
  } finally {
    addItemSession.endSession();
  }

  // Log: who added this item
  ReceiptItemLog.create({
    receiptId: receipt._id,
    itemId: receiptItem._id,
    itemName: receiptItem.name,
    action: 'create',
    actor: getActor(req),
  }).catch((e) => console.error('[ReceiptItemLog] create error:', e));

  const io = getIO();
  if (io) {
    io.to(`receipt_${receipt._id.toString()}`).emit('receipt_item_added', receiptItem);
  }

  res.status(201).json(receiptItem);
}));

router.get('/:id/items', staffOnly, asyncHandler(async (req, res) => {
  const receipt = await Receipt.findById(req.params.id);
  if (!receipt) throw appError('receipt_not_found');

  const items = await ReceiptItem.find({ receiptId: receipt._id }).sort({ createdAt: -1 }).lean();

  // Enrich each item with currentLocation (block + product status) and productCurrentQty
  const productIds = items.map((i) => i.existingProductId || i.createdProductId).filter(Boolean);
  let productMap = {};
  let blockMap = {};

  if (productIds.length > 0) {
    const [products, blocks] = await Promise.all([
      Product.find({ _id: { $in: productIds } }, 'quantity status barcodeChecked barcode').lean(),
      Block.find({ productIds: { $in: productIds } }, 'blockId productIds').lean(),
    ]);
    productMap = Object.fromEntries(products.map((p) => [String(p._id), p]));
    for (const block of blocks) {
      for (const pid of block.productIds) {
        blockMap[String(pid)] = block.blockId;
      }
    }
  }

  const enrichedItems = items.map((item) => {
    const productId = item.existingProductId || item.createdProductId;
    const product = productId ? productMap[String(productId)] : null;
    const blockId = productId ? (blockMap[String(productId)] ?? null) : null;
    return {
      ...item,
      currentLocation: { blockId, status: product?.status ?? null },
      productCurrentQty: product?.quantity ?? null,
      barcodeChecked: product?.barcodeChecked ?? false,
    };
  });

  res.json(enrichedItems);
}));

// ОНОВЛЕННЯ ПОЗИЦІЇ (PATCH)
router.patch('/:id/items/:itemId', staffOnly, asyncHandler(async (req, res) => {
  if (!req.is('multipart/form-data')) {
    throw appError('validation_failed', { field: 'multipart/form-data is required' });
  }

  // Validate item existence BEFORE consuming the body.
  const [receipt, item] = await Promise.all([
    Receipt.findById(req.params.id).lean(),
    ReceiptItem.findOne({ _id: req.params.itemId, receiptId: req.params.id }),
  ]);
  if (!item) throw appError('receipt_item_not_found');
  if (!receipt) throw appError('receipt_not_found');
  // A COMMITTED receipt is a frozen acceptance record — fully read-only.
  // Post-commit edits to price/qty/photo are gone: those now happen at the
  // product's OWNER (warehouse Product or shop ShopProduct), never on the
  // invoice. The freeze is enforced below, once we know what actually changed.

  const parsed = await parseMultipart(req);

  const existingProductId = parsed.fields.existingProductId ? String(parsed.fields.existingProductId).trim() : null;
  if (existingProductId) {
    const exists = await Product.exists({ _id: existingProductId });
    if (!exists) throw appError('validation_failed', { field: 'existingProductId' });
  }
  const deliveryGroupIds = safeParseArray(parsed.fields.deliveryGroupIds);
  if (deliveryGroupIds === null) {
    throw appError('validation_failed', { field: 'deliveryGroupIds' });
  }
  if (deliveryGroupIds.length > 0) {
    const existingCount = await DeliveryGroup.countDocuments({ _id: { $in: deliveryGroupIds } });
    if (existingCount !== deliveryGroupIds.length) {
      throw appError('validation_failed', { field: 'deliveryGroupIds' });
    }
  }
  const qtyPerShop = parseIntField(parsed.fields.qtyPerShop);

  // ── Resolve destination + structure → derived shelf/transit split ──────────
  const prevStructure = item.structure && item.structure.toObject
    ? item.structure.toObject()
    : (item.structure || { type: 'direct' });

  let nextDestination = item.destination || 'shelf';
  if (parsed.fields.destination !== undefined) {
    nextDestination = String(parsed.fields.destination);
    if (!['shelf', 'shops'].includes(nextDestination)) throw appError('receipt_destination_required');
  }
  // Groups intentionally not required — destination is a marker for now.

  let nextStructure = prevStructure;
  let totalQty = item.totalQty;
  if (parsed.fields.structure !== undefined) {
    const rawStructure = safeParseObject(parsed.fields.structure);
    if (rawStructure === undefined) throw appError('receipt_structure_invalid');
    const manual = parsed.fields.totalQty !== undefined
      ? parseIntField(parsed.fields.totalQty, item.totalQty)
      : item.totalQty;
    const resolved = resolveStructure(rawStructure || { type: 'direct' }, manual);
    nextStructure = resolved.structure;
    totalQty = resolved.totalQty;
  } else if (parsed.fields.totalQty !== undefined) {
    totalQty = parseIntField(parsed.fields.totalQty, item.totalQty);
    if (!Number.isInteger(totalQty) || totalQty < 1) throw appError('receipt_qty_invalid');
  }

  // Only re-derive the shelf/transit split when a split-relevant input was
  // actually submitted. Otherwise preserve the stored values — this protects
  // legacy items (no destination field) from being silently zeroed when a
  // non-owner edits only price/qtyPerPackage.
  const splitInputsChanged =
    parsed.fields.destination !== undefined ||
    parsed.fields.structure !== undefined ||
    parsed.fields.totalQty !== undefined;
  const { shelfQty, transitQty } = splitInputsChanged
    ? deriveSplit(nextDestination, totalQty)
    : { shelfQty: item.shelfQty, transitQty: item.transitQty };

  // «Дозамовлення» (§4). Прапорець ЗАВЖДИ перераховується, навіть коли клієнт
  // його не надіслав: перемикання призначення на «На магазини» мусить його
  // погасити саме по собі, інакше позиція поїхала б у магазини з увімкненим
  // дозамовленням, яке ніхто вже не бачить у формі.
  const nextSupplementOffer = nextDestination === 'shelf'
    ? (parsed.fields.supplementOffer !== undefined
      ? parsed.fields.supplementOffer === 'true'
      : !!item.supplementOffer)
    : false;

  // ── Build the set of fields this request actually changes, then enforce
  // the multi-worker ownership rules (also blocks edits to confirmed items).
  const arraysEqual = (a = [], b = []) =>
    a.length === b.length && a.every((v, i) => String(v) === String(b[i]));
  const changedFields = [];
  if (parsed.fields.name !== undefined && String(parsed.fields.name).trim() !== (item.name || '')) changedFields.push('name');
  if (parsed.fields.price !== undefined) {
    const np = parsed.fields.price !== '' ? Number(parsed.fields.price) : null;
    if (np !== item.price) changedFields.push('price');
  }
  if (parsed.fields.qtyPerPackage !== undefined
      && (parsed.fields.qtyPerPackage !== '' ? Number(parsed.fields.qtyPerPackage) : null) !== item.qtyPerPackage) changedFields.push('qtyPerPackage');
  if (parsed.fields.barcode !== undefined && String(parsed.fields.barcode).trim() !== (item.barcode || '')) changedFields.push('barcode');
  if (nextDestination !== (item.destination || 'shelf')) changedFields.push('destination');
  if (nextSupplementOffer !== !!item.supplementOffer) changedFields.push('supplementOffer');
  if (totalQty !== item.totalQty) changedFields.push('totalQty');
  if (JSON.stringify(nextStructure) !== JSON.stringify(prevStructure)) changedFields.push('structure');
  if (parsed.fields.deliveryGroupIds !== undefined && !arraysEqual(deliveryGroupIds, item.deliveryGroupIds || [])) changedFields.push('deliveryGroupIds');
  if (parsed.fields.qtyPerShop !== undefined && qtyPerShop !== (item.qtyPerShop || 0)) changedFields.push('qtyPerShop');
  if (parsed.fields.notes !== undefined && String(parsed.fields.notes).trim() !== (item.notes || '')) changedFields.push('notes');
  const newDefectUrls = defectUrlsFromFilenames(parsed.fields.defectFilenames);
  const hasMultipartDefect = (parsed.files || []).some((f) => f.field === 'defectPhoto');
  const hasNewDefectPhotos = newDefectUrls.length > 0 || hasMultipartDefect;
  // keptDefectPhotoUrls = the subset of EXISTING defect photos the client wants
  // to keep (lets the UI delete individual photos). Absent => keep all existing.
  const keptDefectUrls = parsed.fields.keptDefectPhotoUrls !== undefined
    ? (safeParseArray(parsed.fields.keptDefectPhotoUrls) || [])
    : null;
  const defectsTouched = hasNewDefectPhotos
    || (keptDefectUrls !== null
        && JSON.stringify(keptDefectUrls) !== JSON.stringify(item.defectPhotoUrls || []));
  if (defectsTouched) changedFields.push('defectPhotoUrls');
  const hasNewMainPhoto = (parsed.files || []).some(
    (f) => f.field === 'photo' || !f.field, // legacy callers send the photo with no field name
  );
  if (hasNewMainPhoto) changedFields.push('photoUrl');
  if (parsed.fields.existingProductId !== undefined &&
      (existingProductId || null) !== (item.existingProductId ? String(item.existingProductId) : null)) {
    changedFields.push('existingProductId');
  }

  // Detect changes to the photo overlay metadata (comment + position).
  // If the client sent `photoMeta`, normalize and compare to the stored
  // value and mark it as changed when different.
  if (parsed.fields.photoMeta !== undefined) {
    const rawPhotoMeta = safeParseObject(parsed.fields.photoMeta);
    if (rawPhotoMeta === undefined) throw appError('validation_failed', { field: 'photoMeta' });
    if (rawPhotoMeta && typeof rawPhotoMeta === 'object') {
      const prevMeta = item.photoMeta || { comment: '', commentPos: { x: 0.5, y: 0.5 } };
      const newMeta = {
        comment: String(rawPhotoMeta.comment || ''),
        commentPos: {
          x: Number(rawPhotoMeta?.commentPos?.x) || 0.5,
          y: Number(rawPhotoMeta?.commentPos?.y) || 0.5,
        },
      };
      if (newMeta.comment !== (prevMeta.comment || '')
          || newMeta.commentPos.x !== (prevMeta.commentPos?.x || 0.5)
          || newMeta.commentPos.y !== (prevMeta.commentPos?.y || 0.5)) {
        changedFields.push('photoMeta');
      }
    }
  }

  // Freeze: a committed receipt accepts NO field changes. Edit the product at
  // its owner (warehouse / shop), not on the invoice.
  if (receipt.status === 'completed' && changedFields.length > 0) {
    throw appError('receipt_completed_locked');
  }

  assertCanEditItem(req.user, item, changedFields);

  // Capture values before changes for diff
  const _oldSnapshot = {
    name: item.name,
    totalQty: item.totalQty,
    transitQty: item.transitQty,
    shelfQty: item.shelfQty,
    price: item.price,
    qtyPerPackage: item.qtyPerPackage,
    qtyPerShop: item.qtyPerShop,
    barcode: item.barcode,
    photoUrl: item.photoUrl,
  };

  item.totalQty = totalQty;
  item.transitQty = transitQty;
  item.shelfQty = shelfQty;
  item.destination = nextDestination;
  item.supplementOffer = nextSupplementOffer;
  item.structure = nextStructure;
  item.deliveryGroupIds = deliveryGroupIds;
  item.qtyPerShop = qtyPerShop;
  if (parsed.fields.name !== undefined) item.name = String(parsed.fields.name).trim();
  if (parsed.fields.price !== undefined) item.price = parseNumberField(parsed.fields.price, 'price');
  if (parsed.fields.qtyPerPackage !== undefined) item.qtyPerPackage = parseNumberField(parsed.fields.qtyPerPackage, 'qtyPerPackage');
  if (parsed.fields.barcode !== undefined) item.barcode = String(parsed.fields.barcode).trim();
  item.existingProductId = existingProductId || null;
  if (parsed.fields.notes !== undefined) item.notes = String(parsed.fields.notes).trim();
  let uploadedDefectUrls = [];
  if (defectsTouched) {
    const kept = keptDefectUrls !== null ? keptDefectUrls : (item.defectPhotoUrls || []);
    uploadedDefectUrls = newDefectUrls.length
      ? newDefectUrls
      : (hasMultipartDefect ? await uploadDefectPhotos(parsed.files) : []);
    item.defectPhotoUrls = [...kept, ...uploadedDefectUrls].slice(0, 3);
  }

  // Re-rendered overlay metadata (comment + its position). Owner-only when it
  // changes; a non-owner price edit re-sends the SAME meta so it won't trip.
  const photoMeta = safeParseObject(parsed.fields.photoMeta) || null;
  if (photoMeta && typeof photoMeta === 'object') {
    item.photoMeta = {
      comment: String(photoMeta.comment || ''),
      commentPos: {
        x: Number(photoMeta?.commentPos?.x) || 0.5,
        y: Number(photoMeta?.commentPos?.y) || 0.5,
      },
      pricePos: photoMeta.pricePos || null,
      qtyPos:   photoMeta.qtyPos || null,
    };
  }

  const originalFilename = safeUploadName(parsed.fields.originalFilename);
  if (originalFilename) {
    // CLEAN original → originals/ (see create path); never the labelled photo.
    item.originalPhotoUrl = r2Url('originals', originalFilename);
  }

  const photoFilename = safeUploadName(parsed.fields.photoFilename);
  if (photoFilename) {
    item.photoUrl = r2Url('products', photoFilename);
    item.photoName = photoFilename;
  } else if (!item.photoUrl && existingProductId) {
    const existingProduct = await Product.findById(existingProductId).lean();
    if (existingProduct) {
      item.photoUrl = existingProduct.imageUrls?.[0] || existingProduct.localImageUrl || item.photoUrl;
      item.photoName = existingProduct.imageNames?.[0] || existingProduct.imageUrls?.[0] || item.photoName;
    }
  }

  // Save item AND re-check receipt.status='draft' in the SAME transaction so
  // that a concurrent commit (which CAS-flips status to 'completed') will
  // either run before us (we abort with 409) or run after us (it sees our
  // changes). Без цього вікно між початковою перевіркою і item.save() могло
  // дати «змінив позицію вже завершеної накладної».
  const txSession = await mongoose.connection.startSession();
  try {
    await txSession.withTransaction(async () => {
      const liveReceipt = await Receipt.findOne(
        { _id: req.params.id },
        '_id status',
      ).session(txSession);
      if (!liveReceipt) throw appError('receipt_not_found');
      await item.save({ session: txSession });
    });
  } catch (txErr) {
    // Transaction failed after defect photos were already uploaded — clean them up.
    cleanupDefectPhotos(uploadedDefectUrls).catch(() => {});
    throw txErr;
  } finally {
    txSession.endSession();
  }

  // Log: which fields changed and who changed them
  const _newSnapshot = {
    name: item.name,
    totalQty: item.totalQty,
    transitQty: item.transitQty,
    shelfQty: item.shelfQty,
    price: item.price,
    qtyPerPackage: item.qtyPerPackage,
    qtyPerShop: item.qtyPerShop,
    barcode: item.barcode,
    photoUrl: item.photoUrl,
  };
  const _logChanges = Object.entries(_oldSnapshot)
    .filter(([field]) => String(_oldSnapshot[field] ?? '') !== String(_newSnapshot[field] ?? ''))
    .map(([field]) => ({ field, label: FIELD_LABELS[field] || field, from: _oldSnapshot[field], to: _newSnapshot[field] }));
  if (_logChanges.length > 0) {
    ReceiptItemLog.create({
      receiptId: receipt._id,
      itemId: item._id,
      itemName: item.name,
      action: 'update',
      actor: getActor(req),
      changes: _logChanges,
    }).catch((e) => console.error('[ReceiptItemLog] update error:', e));
  }

  // If barcode was explicitly submitted and there's a linked existing product, enrich the Product record.
  // We also set barcodeChecked: true when the field is empty — that means the user confirmed "no barcode".
  if (parsed.fields.barcode !== undefined && item.existingProductId) {
    const newBarcode = String(parsed.fields.barcode).trim();
    const update = { barcodeChecked: true };
    if (newBarcode) update.barcode = newBarcode;
    await Product.findByIdAndUpdate(item.existingProductId, { $set: update });
  }

  const io = getIO();
  if (io) io.to(`receipt_${req.params.id}`).emit('receipt_item_updated', item);

  res.json(item);
}));

// ВИДАЛЕННЯ ПОЗИЦІЇ (DELETE)
router.delete('/:id/items/:itemId', staffOnly, asyncHandler(async (req, res) => {
  const session = await mongoose.connection.startSession();
  try {
    let deletedItem = null;

    await session.withTransaction(async () => {
      // Атомарна перевірка статусу + delete у одній сесії: захищає від race
      // condition «commit накладної проскочив після перевірки, до видалення».
      const receipt = await Receipt.findOne(
        { _id: req.params.id },
        '_id status',
      ).session(session);
      if (!receipt) throw appError('receipt_not_found');
      if (receipt.status !== 'draft') throw appError('receipt_completed_no_delete');

      const item = await ReceiptItem.findOne(
        { _id: req.params.itemId, receiptId: req.params.id },
      ).session(session);
      if (!item) throw appError('receipt_item_not_found');

      // Only the worker who added it (or admin) may delete, and never once
      // it has been confirmed. Checked inside the txn so a concurrent
      // confirm/commit cannot slip between the check and the delete.
      assertCanDeleteItem(req.user, item);

      await item.deleteOne({ session });
      deletedItem = item;

      // If confirm had created a shop-owned ShopProduct, remove it too.
      if (deletedItem.createdShopProductId) {
        await ShopProduct.deleteOne({ _id: deletedItem.createdShopProductId }).session(session);
      }
    });

    // Аудит-лог видалення позиції — обов'язковий слід для розслідувань
    // (раніше DELETE не писав у ReceiptItemLog взагалі).
    ReceiptItemLog.create({
      receiptId: req.params.id,
      itemId: deletedItem._id,
      itemName: deletedItem.name || '',
      action: 'delete',
      actor: getActor(req),
      changes: [
        { field: 'name', label: FIELD_LABELS.name, from: deletedItem.name, to: null },
        { field: 'totalQty', label: FIELD_LABELS.totalQty, from: deletedItem.totalQty, to: null },
        { field: 'price', label: FIELD_LABELS.price, from: deletedItem.price, to: null },
      ],
    }).catch((e) => console.error('[ReceiptItemLog] delete error:', e));

    const io = getIO();
    if (io) io.to(`receipt_${req.params.id}`).emit('receipt_item_deleted', req.params.itemId);

    res.json({ message: 'Позицію видалено' });
  } finally {
    session.endSession();
  }
}));

// ── CONFIRM / UNCONFIRM A SINGLE ITEM ─────────────────────────────────────
// Only the worker who added the item (or an admin) may sign it off. A receipt
// can only be committed once every non-deleted item is confirmed.
router.post('/:id/items/:itemId/confirm', staffOnly, asyncHandler(async (req, res) => {
  const session = await mongoose.connection.startSession();
  try {
    let confirmedItem = null;
    let confirmedProduct = null;
    // ShopProducts that need (re)embedding — scheduled AFTER commit so we never
    // embed a doc that could still roll back. Reset on every transaction attempt.
    let embedTargets = [];
    await session.withTransaction(async () => {
      embedTargets = [];
      const receipt = await Receipt.findById(req.params.id).session(session);
      const item = await ReceiptItem.findOne({ _id: req.params.itemId, receiptId: req.params.id }).session(session);
      if (!item) throw appError('receipt_item_not_found');
      if (!receipt || receipt.status !== 'draft') throw appError('receipt_completed_locked');

      assertCanConfirmItem(req.user, item);
      assertItemReadyToConfirm(item);

      if (item.status !== 'confirmed') {
        item.status = 'confirmed';
        await item.save({ session });
      }

      const product = await ensureReceiptItemProduct(item, session);
      confirmedProduct = product;

      // Shop-catalog routing by destination — now INSIDE the stock transaction so
      // a warehouse Product can NEVER commit without its ShopProduct mirror, and a
      // shop-owned entry's back-link (createdShopProductId) is persisted atomically.
      // Previously these ran fire-and-forget after the txn: a crash/error there left
      // a confirmed Product with no mirror that nothing retried (re-confirm is
      // blocked once confirmed). Embeddings are deferred to after commit.
      if (product) {
        // shelf item → ShopProduct MIRROR of the warehouse product (linkedProductId set).
        // syncMirror CREATES the mirror if missing then PUSHES the warehouse's current
        // shared values, so a re-receipt into a product that already has a mirror can't
        // leave its price/qtyPerPackage/photo/description stale. In-transaction (session)
        // so a warehouse Product can never commit without its mirror.
        await syncMirror(product, { session });
        // Warehouse OWNS the Gemini vector (its ProductVector row); embed once
        // post-commit. embedProduct is idempotent — it skips when the row already
        // exists (re-receipt), so no gate is needed here. The mirror references this
        // same row at search time, so there is nothing separate to embed for it.
        if (product.originalImageUrl || product.imageUrls?.[0]) {
          embedTargets.push(['warehouse', product, 'receipt-confirm-warehouse']);
        }
      } else if ((item.destination || 'shelf') === 'shops' && !item.existingProductId) {
        // brand-new shops item → shop-OWNED ShopProduct (no warehouse product).
        // (shops + existingProductId is a pure transit marker → nothing to create.)
        const sp = await upsertShopOwnedFromReceiptItem(item.toObject(), { session });
        if (sp && String(sp._id) !== String(item.createdShopProductId || '')) {
          item.createdShopProductId = sp._id;
          await item.save({ session });
        }
        if (sp && (sp.imageUrl || sp.originalImageUrl)) embedTargets.push(['shop-owned', sp, 'shop-owned-upsert']);
      }

      confirmedItem = item.toObject();
      confirmedItem.currentLocation = {
        blockId: null,
        status: product?.status ?? null,
      };
      confirmedItem.productCurrentQty = product?.quantity ?? null;
      confirmedItem.barcodeChecked = product?.barcodeChecked ?? false;
    });
    // Audit log AFTER commit (not inside the callback): withTransaction re-runs the
    // callback on a WriteConflict, so an in-callback create would write one log row
    // per attempt — and a row even if the transaction ultimately aborted.
    ReceiptItemLog.create({
      receiptId: confirmedItem.receiptId,
      itemId: confirmedItem._id,
      itemName: confirmedItem.name,
      action: 'confirm',
      actor: getActor(req),
      changes: [{ field: 'status', label: 'Статус', from: 'draft', to: 'confirmed' }],
    }).catch((e) => console.error('[ReceiptItemLog] confirm error:', e));
    // Docs are now durable — schedule background Gemini embedding into ProductVector.
    // Warehouse products embed by productId; shop-owned items by shopProductId. Mirrors
    // are never embedded (they reference the warehouse row).
    for (const [kind, doc, reason] of embedTargets) {
      if (kind === 'warehouse') embedProductAsync(doc, reason);
      else                      embedShopProductAsync(doc, reason); // shop-owned
    }
    const io = getIO();
    if (io) {
      io.to(`receipt_${req.params.id}`).emit('receipt_item_confirmed', confirmedItem);
      io.emit('incoming_updated');
    }
    res.json(confirmedItem);
  } finally {
    session.endSession();
  }
}));

// Reverse a confirmation so the owner can fix a mistake before the receipt is
// committed. Without this, one wrong confirm would permanently block the whole
// receipt (confirmed items can't be edited/deleted) with no non-admin recovery.
router.post('/:id/items/:itemId/unconfirm', staffOnly, asyncHandler(async (req, res) => {
  const session = await mongoose.connection.startSession();
  try {
    let updatedItem = null;
    let didUnconfirm = false;
    await session.withTransaction(async () => {
      didUnconfirm = false; // reset per attempt (withTransaction may re-run this)
      const receipt = await Receipt.findById(req.params.id).session(session);
      const item = await ReceiptItem.findOne({ _id: req.params.itemId, receiptId: req.params.id }).session(session);
      if (!item) throw appError('receipt_item_not_found');
      if (!receipt || receipt.status !== 'draft') throw appError('receipt_completed_locked');

      assertCanConfirmItem(req.user, item);

      if (item.status === 'confirmed') {
        if ((item.destination || 'shelf') === 'shops') {
          // shops item: created no warehouse product / stock. Remove the shop-owned
          // catalog entry it created (if any) so a re-confirm — to any destination —
          // starts clean. Never deletes a warehouse mirror (linkedProductId: null guard).
          if (item.createdShopProductId) {
            await ShopProduct.deleteOne({ _id: item.createdShopProductId, linkedProductId: null }).session(session);
            item.createdShopProductId = null;
          }
        } else if (item.existingProductId) {
          const product = await Product.findById(item.existingProductId).session(session);
          if (product) {
            product.quantity = Math.max(0, product.quantity - item.shelfQty);
            if (product.quantity === 0) {
              product.status = 'pending';
            }
            await product.save({ session });
          }
        } else if (item.createdProductId) {
          const product = await Product.findById(item.createdProductId).session(session);
          if (product && product.source === 'receipt') {
            const inBlock = await Block.exists({ productIds: product._id }).session(session);
            if (!inBlock) {
              // Also remove the auto-created shop catalog entry so a later
              // re-confirm doesn't leave an orphan + create a duplicate.
              await ShopProduct.deleteOne({ linkedProductId: product._id }).session(session);
              await product.deleteOne({ session });
              item.createdProductId = null;
            }
          }
        }

        item.status = 'draft';
        // Stock was reversed above — allow a later re-confirm to re-apply it.
        item.stockApplied = false;
        await item.save({ session });
        didUnconfirm = true;
      }

      updatedItem = item.toObject();
    });

    // Audit log AFTER commit — see the confirm handler note (avoid per-retry / phantom rows).
    if (didUnconfirm && updatedItem) {
      ReceiptItemLog.create({
        receiptId: updatedItem.receiptId,
        itemId: updatedItem._id,
        itemName: updatedItem.name,
        action: 'confirm',
        actor: getActor(req),
        changes: [{ field: 'status', label: 'Статус', from: 'confirmed', to: 'draft' }],
      }).catch((e) => console.error('[ReceiptItemLog] unconfirm error:', e));
    }

    const io = getIO();
    if (io) {
      io.to(`receipt_${req.params.id}`).emit('receipt_item_confirmed', updatedItem);
      io.emit('incoming_updated');
    }

    res.json(updatedItem);
  } finally {
    session.endSession();
  }
}));

router.post('/:id/commit', staffOnly, asyncHandler(async (req, res) => {
  // Cheap pre-flight (avoids opening a session for the obviously-bad case).
  const receiptCheck = await Receipt.findById(req.params.id).lean();
  if (!receiptCheck) throw appError('receipt_not_found');
  if (receiptCheck.status === 'completed') throw appError('receipt_already_completed');

  const session = await mongoose.connection.startSession();
  session.startTransaction();

  try {
    // Atomic CAS: draft → completed. Виконуємо ПЕРШИМ кроком транзакції, щоб
    // паралельний PATCH/DELETE item (який теж перевіряє status='draft' у своїй
    // транзакції) гарантовано побачив новий статус і відмовив запит, а не
    // переписав/видалив позицію вже після нашої перевірки.
    const receipt = await Receipt.findOneAndUpdate(
      { _id: req.params.id, status: 'draft' },
      { $set: { status: 'completed', completedAt: new Date() } },
      { new: true, session },
    );
    if (!receipt) {
      // Do NOT abort/end here — the outer catch owns rollback. Aborting twice
      // on an already-ended session throws a secondary error that masks this
      // one. Just throw; the catch aborts the still-open transaction cleanly.
      throw appError('receipt_already_completed');
    }

    // Re-load items INSIDE the transaction — таким чином усі зміни, які
    // могли пройти між pre-check і CAS, вже або встигли (і ми бачимо актуальний
    // стан), або заблоковані статус-CAS-ом у власних транзакціях.
    const items = await ReceiptItem.find({ receiptId: receipt._id }).session(session);
    if (!items.length) throw appError('receipt_no_items');

    // Multi-worker gate: every item must be signed off by its owner first.
    const pendingConfirm = items.filter((item) => item.status !== 'confirmed').length;
    if (pendingConfirm > 0) {
      throw appError('receipt_items_not_all_confirmed', { pending: pendingConfirm });
    }

    // Receiving needs only a photo + arrived quantity. Name/price are optional
    // shop-data filled separately later — a *confirmed* item has already passed
    // the worker's sign-off, so we don't re-validate name/price here.

    const pendingItem = items.find((item) => item.warehousePending);
    if (pendingItem) throw appError('receipt_item_pending', { name: pendingItem.name });

    // Items may be marked `destination='shops'` without delivery groups.
    // Keep `transitQty` as a bookkeeping/operational marker but do not
    // require deliveryGroupIds here — distribution to sellers is handled
    // by a separate process/worker and **must not** be created during commit.

    const createdProducts = [];

    // 4.1: Pre-determine how many NEW products will be created (no existingProductId or not found),
    // then do ONE bulk shiftUp instead of one per new product.
    // shops items create NO warehouse product, so they are EXCLUDED from this
    // count — including them would over-shift every orderNumber (silent bug).
    const shelfItems = items.filter((i) => (i.destination || 'shelf') !== 'shops');
    const existingIdSet = new Set(
      shelfItems
        .map((i) => i.existingProductId || i.createdProductId)
        .filter(Boolean)
        .map(String)
    );
    let resolvedExistingCount = 0;
    if (existingIdSet.size > 0) {
      resolvedExistingCount = await Product.countDocuments({
        _id: { $in: [...existingIdSet] },
      }).session(session);
    }
    const newProductCount = shelfItems.length - resolvedExistingCount;
    if (newProductCount > 0) {
      await Product.updateMany(
        { orderNumber: { $gte: 1 } },
        { $inc: { orderNumber: newProductCount } },
        { session }
      );
    }
    let nextOrderNumber = 1;

    // 4.2: Track already-updated existingProductIds to prevent double-increment if two items share the same product.
    const usedExistingProductIds = new Set();

    for (const item of items) {
      // shops items never create/update a warehouse product — their shop-catalog
      // routing (shop-owned entry or transit marker) was handled at confirm time.
      if ((item.destination || 'shelf') === 'shops') continue;

      let currentProduct;

      // `item.stockApplied` is the SINGLE source of truth. It is set
      // idempotently by ensureReceiptItemProduct() at confirm time whenever
      // stock is actually added (shelfQty > 0). The old extra
      // `|| item.status === 'confirmed'` clause was wrong in BOTH directions:
      //   • item confirmed while shelfQty===0 (destination=shops, no stock
      //     applied, stockApplied=false) then edited to shelfQty>0 → the
      //     'confirmed' clause made commit skip it → SILENT STOCK LOSS;
      //   • it was also redundant for double-apply (stockApplied already
      //     covers that). Drive strictly off the flag.
      const stockAlreadyApplied = !!item.stockApplied;

      // 1. Update or create the product
      if (
        item.existingProductId &&
        !item.createdProductId &&
        !usedExistingProductIds.has(String(item.existingProductId))
      ) {
        usedExistingProductIds.add(String(item.existingProductId));
        currentProduct = await Product.findById(item.existingProductId).session(session);
        if (currentProduct) {
          if (item.shelfQty > 0 && !stockAlreadyApplied) {
            currentProduct.quantity += item.shelfQty;
          }
          if (item.price !== null) currentProduct.price = item.price;
          if (item.qtyPerPackage) currentProduct.quantityPerPackage = item.qtyPerPackage;
          // INVARIANT «active ⟺ лежить у блоці»: commit НЕ робить товар active.
          // Отриманий товар лишається 'pending' (Надходження), доки склад не
          // покладе його в блок (blocks.js POST /:n/add). Єдиний прямий шлях у
          // 'active' — block_photo (вантажиться одразу в блок). Раніше тут було
          // status='active' → товар ставав active без блока: не видно в Надходженні,
          // збирач не може знайти. Прибрано.
          await currentProduct.save({ session });
          item.createdProductId = currentProduct._id;
          if (item.shelfQty > 0) item.stockApplied = true;
          await item.save({ session });
        }
      }

      if (!currentProduct && item.createdProductId) {
        currentProduct = await Product.findById(item.createdProductId).session(session);
        if (currentProduct) {
          if (item.price !== null) currentProduct.price = item.price;
          if (item.qtyPerPackage) currentProduct.quantityPerPackage = item.qtyPerPackage;
          // Лише кількість (ідемпотентно через stockApplied). Статус лишається
          // 'pending' — active тільки при розкладанні в блок (див. інваріант вище).
          if (item.shelfQty > 0 && !stockAlreadyApplied) {
            currentProduct.quantity = item.shelfQty;
          }
          await currentProduct.save({ session });
        }
      }

      if (!currentProduct) {
        currentProduct = new Product({
          orderNumber: nextOrderNumber++,
          price: item.price ?? 0,
          quantity: item.shelfQty,
          warehouse: '',
          category: '',
          name: item.name || '',
          brand: item.name || '',
          model: '',
          // Ніколи не active автоматично: новий товар ще не в блоці → 'pending'
          // (Надходження), доки його не розкладуть. (Дістається лише якщо confirm
          // чомусь не створив товар; лишаємо коректним про всяк випадок.)
          status: 'pending',
          source: 'receipt',
          imageUrls: [item.photoUrl],
          imageNames: [item.photoName],
          barcode: item.barcode || '',
          quantityPerPackage: item.qtyPerPackage || 0,
          aiDescription: item.aiDescription || '',
        });

        await currentProduct.save({ session });
        item.createdProductId = currentProduct._id;
        await item.save({ session });
      }

      createdProducts.push(currentProduct);

      // 2. Transit allocation
      // Automatic distribution to sellers (creating `direct_allocation` orders)
      // has been intentionally disabled. `transitQty` remains a marker so
      // the operations team can later process shipments to shops without
      // the commit step performing allocations.
    }

    await session.commitTransaction();
    session.endSession();

    ReceiptItemLog.create({
      receiptId: receipt._id,
      itemName: receipt.receiptNumber,
      action: 'receipt_complete',
      actor: getActor(req),
    }).catch((e) => console.error('[ReceiptItemLog] receipt_complete error:', e));

    // Notify warehouse board that new products are available in the incoming strip
    try { getIO().emit('incoming_updated'); } catch (_) {}

    // ── Дозамовлення (§4): запускається ПІСЛЯ проведення ВСІЄЇ накладної ──────
    // Не після підтвердження окремої позиції — власник вирішив саме так, бо
    // хвиля дозамовлення = одна накладна з одним дедлайном (§6).
    //
    // Поза транзакцією свідомо: створення ідемпотентне (унікальний індекс
    // {receiptItemId, deliveryGroupId}), тому повторний виклик нічого не
    // задублює, а збій розсилки не має відкочувати вже проведену накладну.
    // Відповідь клієнту чекає на створення пропозицій (щоб «Проведено» і
    // «дозамовлення відкрито» не розповзалися в часі), а Telegram — ні.
    let supplementOffersCount = 0;
    try {
      const { createOffersForReceipt } = require('../services/supplementOffers');
      const offers = await createOffersForReceipt(receipt._id);
      supplementOffersCount = offers.length;
      if (offers.length) {
        for (const offer of offers) {
          try {
            getIO()?.emit('supplement_opened', {
              offerId: String(offer._id),
              deliveryGroupId: String(offer.deliveryGroupId),
              orderingSessionId: String(offer.orderingSessionId),
              closesAt: offer.closesAt,
            });
          } catch (_) { /* сокет не критичний */ }
        }
        // Розсилка — фоном: Telegram буває повільним, а склад не має чекати на
        // нього, щоб побачити «Накладну проведено».
        require('../services/supplementNotify')
          .notifyOffers(offers, 'opened')
          .catch((e) => console.error('[supplement] стартова розсилка впала:', e?.message));
      }
    } catch (err) {
      // Накладна вже проведена і товар на складі — це головне. Провал відкриття
      // дозамовлення логуємо, але не перетворюємо на помилку проведення.
      console.error('[supplement] не вдалося відкрити дозамовлення для накладної', String(receipt._id), ':', err?.message);
    }

    res.json({ receipt, createdProductsCount: createdProducts.length, supplementOffersCount });
  } catch (err) {
    // Guard both: after a FAILED commitTransaction (e.g. a concurrent-commit
    // WriteConflict) the transaction is already terminal, so an unguarded
    // abortTransaction() throws a SECONDARY error that masks the real one and
    // crashes the handler to 500. Swallow teardown errors so the real cause below wins.
    try { await session.abortTransaction(); } catch { /* already terminal */ }
    try { session.endSession(); } catch { /* idempotent */ }
    // AppError instances are already user-facing; rethrow so the central handler
    // turns them into proper JSON. Anything else becomes a generic commit failure.
    if (err && err.name === 'AppError') throw err;
    if (err && err.name === 'CastError') throw err; // bad :id → global 400, not 500
    // Concurrent double-commit (двічі натиснули «Провести»): the other request won
    // the draft→completed CAS and our transaction hit a transient WriteConflict.
    // Surface a clean 409 (already completed), not a 500.
    const fresh = await Receipt.findById(req.params.id).lean();
    if (fresh && fresh.status === 'completed') throw appError('receipt_already_completed');
    console.error('[receipts.commit] Error:', err);
    throw appError('receipt_commit_failed');
  }
}));

// ── RESOLVE WAREHOUSE-PENDING ─────────────────────────────────────────────
// Link a warehousePending item to an existing product, or mark it as a brand-new product.
router.patch('/:id/items/:itemId/link', staffOnly, asyncHandler(async (req, res) => {
  const { existingProductId, markAsNew, keepNewPhoto } = req.body || {};
  const receipt = await Receipt.findById(req.params.id).lean();
  if (!receipt) throw appError('receipt_not_found');
  if (receipt.status === 'completed') throw appError('receipt_completed_locked');

  const item = await ReceiptItem.findOne({ _id: req.params.itemId, receiptId: req.params.id });
  if (!item) throw appError('receipt_item_not_found');

  if (existingProductId) {
    item.existingProductId = existingProductId;
    const prod = await Product.findById(existingProductId);
    if (prod) {
      if (item.photoUrl && keepNewPhoto === true) {
        // User chose the NEW photo — update the product record so it shows everywhere
        prod.imageUrls = [item.photoUrl, ...(prod.imageUrls || []).filter((u) => u !== item.photoUrl)];
        if (item.photoName) {
          prod.imageNames = [item.photoName, ...(prod.imageNames || []).filter((n) => n !== item.photoName)];
        }
        await prod.save();
      } else if (!item.photoUrl || keepNewPhoto === false) {
        // User chose the OLD photo (or item had no photo) — pull from product
        item.photoUrl = prod.imageUrls?.[0] || prod.localImageUrl || '';
        item.photoName = prod.imageNames?.[0] || '';
      }
      if (!item.name || item.name === 'Без назви') {
        item.name = prod.brand || prod.model || item.name;
      }
      if (item.price == null && prod.price != null) {
        item.price = prod.price;
      }
    }
  }
  item.warehousePending = false;
  await item.save();

  ReceiptItemLog.create({
    receiptId: req.params.id,
    itemId: item._id,
    itemName: item.name,
    action: 'resolve_pending',
    actor: getActor(req),
    meta: { existingProductId: existingProductId || null, markAsNew: !!markAsNew },
  }).catch((e) => console.error('[ReceiptItemLog] resolve_pending error:', e));

  // Return enriched item (same as GET /:id/items enrichment)
  const productId = item.existingProductId || item.createdProductId;
  let enriched = item.toObject();
  if (productId) {
    const [prod, block] = await Promise.all([
      Product.findById(productId, 'quantity status barcodeChecked barcode price').lean(),
      Block.findOne({ productIds: productId }, 'blockId').lean(),
    ]);
    enriched.currentLocation = { blockId: block?.blockId ?? null, status: prod?.status ?? null };
    enriched.productCurrentQty = prod?.quantity ?? null;
    enriched.barcodeChecked = prod?.barcodeChecked ?? false;
  } else {
    enriched.currentLocation = { blockId: null, status: null };
    enriched.productCurrentQty = null;
  }

  const io = getIO();
  if (io) io.to(`receipt_${req.params.id}`).emit('receipt_item_updated', enriched);

  res.json(enriched);
}));

// ── POST /:id/items/:itemId/describe — generate + cache the item description ──
// On-demand during receiving. Plain-language Ukrainian explainer from the item
// photo, cached on the ReceiptItem; copied into the warehouse Product /
// ShopProduct when this item is confirmed. Pressing again regenerates.
router.post('/:id/items/:itemId/describe', staffOnly, asyncHandler(async (req, res) => {
  const item = await ReceiptItem.findOne({ _id: req.params.itemId, receiptId: req.params.id });
  if (!item) throw appError('receipt_item_not_found');

  const url = item.originalPhotoUrl || item.photoUrl || '';
  if (!url) return res.status(400).json({ error: 'photo_required', message: 'У позиції немає фото' });

  if (!getGeminiStatus().connected) {
    return res.status(503).json({ error: 'describe_not_configured', message: 'Опис недоступний: не підключено Gemini' });
  }

  try {
    const { text, name } = await describeImageUrl(url);
    if (!text) return res.status(502).json({ error: 'empty_description', message: 'Не вдалося згенерувати опис' });
    item.aiDescription = text;
    // Fill the name ONLY when the user left it blank — never clobber a manually
    // typed name with the model's guess.
    if (name && !String(item.name || '').trim()) item.name = name;
    await item.save();
    const io = getIO();
    if (io) io.to(`receipt_${req.params.id}`).emit('receipt_item_updated', item.toObject());
    res.json({ _id: item._id, aiDescription: item.aiDescription, name: item.name });
  } catch (err) {
    console.error('[receipts] describe error:', err.message);
    return res.status(502).json({ error: 'describe_api_error', message: err.message });
  }
}));

// ── HISTORY / AUDIT LOG ────────────────────────────────────────────────────

// GET all logs for a receipt (lazy — only called when user explicitly opens history)
router.get('/:id/logs', staffOnly, asyncHandler(async (req, res) => {
  const logs = await ReceiptItemLog.find({ receiptId: req.params.id })
    .sort({ createdAt: -1 })
    .lean();
  res.json(logs);
}));

// POST a move_to_block action from the frontend (addToBlock lives in blocks route, not here)
router.post('/:id/items/:itemId/log', staffOnly, asyncHandler(async (req, res) => {
  const { action, blockId, itemName } = req.body || {};
  if (!action) throw appError('receipt_log_action_required');

  await ReceiptItemLog.create({
    receiptId: req.params.id,
    itemId: req.params.itemId,
    itemName: itemName || '',
    action,
    actor: getActor(req),
    meta: blockId ? { blockId } : {},
  });
  res.json({ ok: true });
}));

module.exports = router;
