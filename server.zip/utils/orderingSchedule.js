'use strict';

/**
 * Ordering window logic for delivery groups.
 *
 * Polish timezone (Europe/Warsaw) is used throughout.
 * DST is handled automatically by the Intl API.
 *
 * Schedule:
 *   Ordering OPENS  — the day before delivery at 16:00, but if that day is Sunday
 *                    then Saturday is used instead (no ordering on Sundays).
 *   Ordering CLOSES — the delivery day itself at 07:30 Warsaw time
 *
 * Example:
 *   Delivery Monday  (dayOfWeek=1) → day-before = Sun → skip → open Sat 16:00, close Mon 07:30
 *   Delivery Tuesday (dayOfWeek=2) → day-before = Mon → open Mon 16:00, close Tue 07:30
 *   Delivery Thursday(dayOfWeek=4) → day-before = Wed → open Wed 16:00, close Thu 07:30
 */

const TIMEZONE = 'Europe/Warsaw';

// No hardcoded schedule defaults. The window hours live ONLY in AppSetting
// ('ordering.schedule', read via utils/getOrderingSchedule) so an admin change
// takes effect everywhere. Previously these functions defaulted to 16:00/07:30
// via `schedule.openHour ?? OPEN_HOUR`, which silently computed the window against
// stale hours whenever a caller forgot to pass the schedule (e.g. users.js list
// view). requireScheduleFields makes every entry point fail loudly instead.
function requireScheduleFields(schedule, fields) {
  const s = schedule || {};
  const out = {};
  for (const f of fields) {
    const v = s[f];
    if (typeof v !== 'number' || !Number.isFinite(v)) {
      throw new Error(
        `orderingSchedule: missing/invalid '${f}' — a schedule from getOrderingSchedule() ` +
        'must be passed (no hardcoded fallback). Got: ' + JSON.stringify(s),
      );
    }
    out[f] = v;
  }
  return out;
}

const DAY_SHORT_UK = ['Нд', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
const DAY_FULL_UK  = ['неділю', 'понеділок', 'вівторок', 'середу', 'четвер', "п'ятницю", 'суботу'];

/**
 * Returns current day-of-week, hour and minute in Warsaw timezone.
 * dayOfWeek: 0=Sun, 1=Mon, …, 6=Sat
 */
function getWarsawNow() {
  const now = new Date();
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone: TIMEZONE,
    weekday: 'short',  // Mon, Tue …
    hour:    '2-digit',
    minute:  '2-digit',
    hour12:  false,
  });
  const parts = fmt.formatToParts(now);
  const get = (type) => parts.find((p) => p.type === type)?.value ?? '';

  const weekdayMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  const dayOfWeek = weekdayMap[get('weekday')] ?? 0;

  // hour12:false returns '24' for midnight on some platforms — normalise
  let hour = parseInt(get('hour'), 10);
  if (hour === 24) hour = 0;
  const minute = parseInt(get('minute'), 10);

  return { dayOfWeek, hour, minute };
}

/**
 * Formats a time as "16:00" (no AM/PM).
 */
function fmt(h, m) {
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/**
 * Checks whether ordering is currently open for a delivery group.
 *
 * openDay  = day before delivery (Sunday → shifted to Saturday).
 * closeDay = delivery day.
 * openDay and closeDay are ALWAYS different calendar days.
 *
 * Time comparison edge cases:
 *   - openTime < closeTime  (e.g. 16:00 → 07:30): normal overnight window — works correctly.
 *   - openTime > closeTime  (e.g. 05:00 → 04:00): window crosses midnight on each boundary day
 *       but since open/close are on different calendar days this is still well-defined:
 *       ordering opens on openDay at 05:00 and closes on closeDay at 04:00.
 *   - openTime === closeTime: zero-length window — rejected at admin input level.
 *
 * Multi-day windows:
 *   Monday delivery (dayOfWeek=1) → dayBefore=Sun → openDay=Sat (Sunday skip)
 *   → window spans Sat 16:00 → Sun (all day) → Mon 07:30 = ~39 hours (2-day window).
 *   The daysFromOpen/daysToClose check in the "any other day" branch covers Sunday correctly.
 *
 * @param {number} deliveryDayOfWeek  0=Sun … 6=Sat  (the day the warehouse collects)
 * @param {{ openHour?: number, openMinute?: number, closeHour?: number, closeMinute?: number }} [schedule]
 * @returns {{ isOpen: boolean, message: string }}
 */
function isOrderingOpen(deliveryDayOfWeek, schedule) {
  const { openHour, openMinute, closeHour, closeMinute } =
    requireScheduleFields(schedule, ['openHour', 'openMinute', 'closeHour', 'closeMinute']);

  const { dayOfWeek, hour, minute } = getWarsawNow();

  // Day before delivery; if that falls on Sunday (0) — use Saturday (6) instead
  const dayBefore = (deliveryDayOfWeek - 1 + 7) % 7;
  const openDay  = dayBefore === 0 ? 6 : dayBefore;
  const closeDay = deliveryDayOfWeek;

  const nowMins   = hour * 60 + minute;
  const openMins  = openHour  * 60 + openMinute;
  const closeMins = closeHour * 60 + closeMinute;

  // --- same day as OPEN day ---
  if (dayOfWeek === openDay) {
    if (nowMins >= openMins) {
      return {
        isOpen: true,
        message: `Закривається в ${DAY_FULL_UK[closeDay]} о ${fmt(closeHour, closeMinute)}`,
      };
    }
    return {
      isOpen: false,
      message: `Замовлення відкриються сьогодні о ${fmt(openHour, openMinute)}`,
    };
  }

  // --- same day as CLOSE day ---
  if (dayOfWeek === closeDay) {
    if (nowMins < closeMins) {
      return {
        isOpen: true,
        message: `Закривається сьогодні о ${fmt(closeHour, closeMinute)}`,
      };
    }
    return {
      isOpen: false,
      message: `Замовлення закрито. Наступне вікно — ${DAY_FULL_UK[openDay]} о ${fmt(openHour, openMinute)}`,
    };
  }

  // --- any other day ---
  // Check if we're inside the open window (between openDay+openTime and closeDay+closeTime).
  // The window can span multiple days (e.g. Sat 16:00 → Mon 07:30 for Monday delivery).
  // We check: is current day strictly between openDay and closeDay (mod 7)?
  const daysFromOpen = (dayOfWeek - openDay + 7) % 7;
  const daysToClose  = (closeDay - dayOfWeek + 7) % 7;
  // Window length in days (openDay → closeDay)
  const windowDays = (closeDay - openDay + 7) % 7;

  if (daysFromOpen > 0 && daysFromOpen <= windowDays && daysToClose > 0) {
    // We're on a day strictly inside the open window
    return {
      isOpen: true,
      message: `Закривається в ${DAY_FULL_UK[closeDay]} о ${fmt(closeHour, closeMinute)}`,
    };
  }

  return {
    isOpen: false,
    message: `Відкриються в ${DAY_FULL_UK[openDay]} о ${fmt(openHour, openMinute)}, закриються в ${DAY_FULL_UK[closeDay]} о ${fmt(closeHour, closeMinute)}`,
  };
}

/**
 * Returns window times for display purposes.
 */
function getWindowDescription(deliveryDayOfWeek, schedule) {
  const { openHour, openMinute, closeHour, closeMinute } =
    requireScheduleFields(schedule, ['openHour', 'openMinute', 'closeHour', 'closeMinute']);

  const dayBefore = (deliveryDayOfWeek - 1 + 7) % 7;
  const openDay  = dayBefore === 0 ? 6 : dayBefore;
  const closeDay = deliveryDayOfWeek;
  return {
    openDay,
    closeDay,
    openTime:  fmt(openHour, openMinute),
    closeTime: fmt(closeHour, closeMinute),
    openDayName:  DAY_SHORT_UK[openDay],
    closeDayName: DAY_SHORT_UK[closeDay],
    openDayNameFull:  DAY_FULL_UK[openDay],
    closeDayNameFull: DAY_FULL_UK[closeDay],
  };
}

/**
 * Converts a wall-clock date/time in Warsaw timezone to a UTC Date.
 * Uses a one-step offset approximation — accurate for all non-DST-transition moments.
 */
function warsawWallClockToUTC(year, month, day, hour, minute) {
  // Estimate UTC by assuming UTC+1 (Warsaw winter time)
  const approx = new Date(Date.UTC(year, month - 1, day, hour - 1, minute));

  // Find the actual Warsaw offset for this approximate UTC moment
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: TIMEZONE,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: false,
  }).formatToParts(approx);
  const g = (t) => parseInt(parts.find((p) => p.type === t)?.value ?? '0', 10);

  // offsetMs = (Warsaw wall clock read as UTC) − actual UTC
  const warsawAsUTC = Date.UTC(g('year'), g('month') - 1, g('day'), g('hour'), g('minute'));
  const offsetMs = warsawAsUTC - approx.getTime();

  // target UTC = target Warsaw wall clock (as UTC) − offset
  return new Date(Date.UTC(year, month - 1, day, hour, minute) - offsetMs);
}

/**
 * Returns the UTC Date when the current ordering window opened for the given group.
 * This is the most recent past occurrence of (openDay at openHour:openMinute Warsaw time).
 *
 * @param {number} deliveryDayOfWeek  0=Sun … 6=Sat
 * @param {{ openHour?: number, openMinute?: number }} [schedule]
 * @returns {Date}
 */
function getOrderingWindowOpenAt(deliveryDayOfWeek, schedule) {
  const { openHour, openMinute } = requireScheduleFields(schedule, ['openHour', 'openMinute']);

  // Which weekday does the window open on? (day before delivery; Sunday → Saturday)
  const dayBefore = (deliveryDayOfWeek - 1 + 7) % 7;
  const openDay   = dayBefore === 0 ? 6 : dayBefore;

  const { dayOfWeek: nowDOW, hour: nowHour, minute: nowMinute } = getWarsawNow();
  const nowMins  = nowHour * 60 + nowMinute;
  const openMins = openHour * 60 + openMinute;

  // How many days back is the last occurrence of openDay?
  let daysBack = (nowDOW - openDay + 7) % 7;
  // If today IS openDay but we haven't passed openTime yet → look back a full week
  if (daysBack === 0 && nowMins < openMins) {
    daysBack = 7;
  }

  // Get current Warsaw calendar date
  const now = new Date();
  const dateParts = new Intl.DateTimeFormat('en-US', {
    timeZone: TIMEZONE,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour12: false,
  }).formatToParts(now);
  const gd = (t) => parseInt(dateParts.find((p) => p.type === t)?.value ?? '0', 10);

  // Subtract daysBack; Date.UTC handles month/year rollover automatically
  const target = new Date(Date.UTC(gd('year'), gd('month') - 1, gd('day') - daysBack));

  return warsawWallClockToUTC(
    target.getUTCFullYear(),
    target.getUTCMonth() + 1,
    target.getUTCDate(),
    openHour,
    openMinute,
  );
}

/**
 * Returns the Warsaw calendar date string ("YYYY-MM-DD") for the day the ordering window
 * opens for the given delivery group. Stable even if admin changes the open time.
 *
 * This is the unique key (with groupId) of an OrderingSession, so it MUST be
 * derived purely from calendar arithmetic — never from a UTC timestamp round-trip.
 * The previous implementation went Warsaw-date → wall-clock 16:00 → UTC (via the
 * one-step offset approximation in warsawWallClockToUTC) → format back to a Warsaw
 * date. On the two DST-transition days per year that round-trip could land the UTC
 * moment on the far side of midnight and format back to the ADJACENT calendar date,
 * splitting one logical ordering window into two OrderingSession documents (orders
 * scattered across two orderingSessionIds → false conflicts + half-built picking).
 * Computing the date directly from (today − daysBack) in the Warsaw calendar removes
 * the timestamp from the equation entirely, so DST cannot shift the key. openAt
 * (the precise instant) is still computed separately via getOrderingWindowOpenAt.
 *
 * @param {number} deliveryDayOfWeek  0=Sun … 6=Sat
 * @param {{ openHour?: number, openMinute?: number }} [schedule]
 * @returns {string}  e.g. "2024-01-20"
 */
function getOpenDateWarsaw(deliveryDayOfWeek, schedule) {
  const { openHour, openMinute } = requireScheduleFields(schedule, ['openHour', 'openMinute']);

  // Which weekday does the window open on? (day before delivery; Sunday → Saturday)
  const dayBefore = (deliveryDayOfWeek - 1 + 7) % 7;
  const openDay   = dayBefore === 0 ? 6 : dayBefore;

  const { dayOfWeek: nowDOW, hour: nowHour, minute: nowMinute } = getWarsawNow();
  const nowMins  = nowHour * 60 + nowMinute;
  const openMins = openHour * 60 + openMinute;

  // How many days back is the last occurrence of openDay?
  let daysBack = (nowDOW - openDay + 7) % 7;
  // If today IS openDay but we haven't passed openTime yet → look back a full week.
  // (Mirrors getOrderingWindowOpenAt so openDate and openAt always agree on which
  // window is "current".)
  if (daysBack === 0 && nowMins < openMins) {
    daysBack = 7;
  }

  // Today's Warsaw calendar date, then step back daysBack whole days. Date.UTC is
  // used only as a calendar (no timezone semantics): we read Y/M/D in Warsaw,
  // subtract days, and re-read Y/M/D — midnight UTC of a date carries that date's
  // Y/M/D, so this is pure calendar math, immune to DST.
  const now = new Date();
  const dateParts = new Intl.DateTimeFormat('en-US', {
    timeZone: TIMEZONE,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour12: false,
  }).formatToParts(now);
  const gd = (t) => parseInt(dateParts.find((p) => p.type === t)?.value ?? '0', 10);

  const target = new Date(Date.UTC(gd('year'), gd('month') - 1, gd('day') - daysBack));

  const y = target.getUTCFullYear();
  const m = String(target.getUTCMonth() + 1).padStart(2, '0');
  const d = String(target.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Returns the UTC Date when the current ordering window will close for the given group.
 * This is the next future occurrence of (closeDay at closeHour:closeMinute Warsaw time).
 *
 * @param {number} deliveryDayOfWeek  0=Sun … 6=Sat
 * @param {{ closeHour?: number, closeMinute?: number }} [schedule]
 * @returns {Date}
 */
function getOrderingWindowCloseAt(deliveryDayOfWeek, schedule) {
  const { closeHour, closeMinute } = requireScheduleFields(schedule, ['closeHour', 'closeMinute']);
  const closeDay = deliveryDayOfWeek;

  const { dayOfWeek: nowDOW, hour: nowHour, minute: nowMinute } = getWarsawNow();
  const nowMins   = nowHour * 60 + nowMinute;
  const closeMins = closeHour * 60 + closeMinute;

  // How many days ahead is the next occurrence of closeDay?
  let daysAhead = (closeDay - nowDOW + 7) % 7;
  // If today IS closeDay but we've already passed closeTime → next week
  if (daysAhead === 0 && nowMins >= closeMins) {
    daysAhead = 7;
  }

  // Get current Warsaw calendar date
  const now = new Date();
  const dateParts = new Intl.DateTimeFormat('en-US', {
    timeZone: TIMEZONE,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour12: false,
  }).formatToParts(now);
  const gd = (t) => parseInt(dateParts.find((p) => p.type === t)?.value ?? '0', 10);

  const target = new Date(Date.UTC(gd('year'), gd('month') - 1, gd('day') + daysAhead));

  return warsawWallClockToUTC(
    target.getUTCFullYear(),
    target.getUTCMonth() + 1,
    target.getUTCDate(),
    closeHour,
    closeMinute,
  );
}

/**
 * Returns the UTC Date when the ordering window LAST closed for the given group —
 * the most recent PAST occurrence of (closeDay at closeHour:closeMinute Warsaw).
 *
 * Mirror image of getOrderingWindowOpenAt (which finds the last past open), and
 * deliberately NOT "next close − 7 days": that subtraction is wrong by an hour
 * across the two DST transitions, and this value is shown to a human as
 * "замовлення закрилися 3 години тому".
 *
 * @param {number} deliveryDayOfWeek  0=Sun … 6=Sat
 * @param {{ closeHour?: number, closeMinute?: number }} [schedule]
 * @returns {Date}
 */
function getPreviousOrderingCloseAt(deliveryDayOfWeek, schedule) {
  const { closeHour, closeMinute } = requireScheduleFields(schedule, ['closeHour', 'closeMinute']);
  const closeDay = deliveryDayOfWeek;

  const { dayOfWeek: nowDOW, hour: nowHour, minute: nowMinute } = getWarsawNow();
  const nowMins   = nowHour * 60 + nowMinute;
  const closeMins = closeHour * 60 + closeMinute;

  // How many days back is the last occurrence of closeDay?
  let daysBack = (nowDOW - closeDay + 7) % 7;
  // Today IS closeDay but the close time hasn't arrived yet → look back a week.
  if (daysBack === 0 && nowMins < closeMins) daysBack = 7;

  const now = new Date();
  const dateParts = new Intl.DateTimeFormat('en-US', {
    timeZone: TIMEZONE,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour12: false,
  }).formatToParts(now);
  const gd = (t) => parseInt(dateParts.find((p) => p.type === t)?.value ?? '0', 10);

  const target = new Date(Date.UTC(gd('year'), gd('month') - 1, gd('day') - daysBack));

  return warsawWallClockToUTC(
    target.getUTCFullYear(),
    target.getUTCMonth() + 1,
    target.getUTCDate(),
    closeHour,
    closeMinute,
  );
}

/**
 * True if the ordering window opens today and starts within `withinMinutes`.
 * Mirror of client/src/utils/orderingSchedule.js:isOrderingOpeningSoon.
 * @param {number} deliveryDayOfWeek 0=Sun…6=Sat
 * @param {{ openHour?: number, openMinute?: number }} schedule
 * @param {number} withinMinutes default 240 (4 hours)
 */
function isOrderingOpeningSoon(deliveryDayOfWeek, schedule, withinMinutes = 240) {
  const { openHour, openMinute } = requireScheduleFields(schedule, ['openHour', 'openMinute']);
  const { dayOfWeek, hour, minute } = getWarsawNow();

  const dayBefore = (deliveryDayOfWeek - 1 + 7) % 7;
  const openDay   = dayBefore === 0 ? 6 : dayBefore;
  if (dayOfWeek !== openDay) return false;

  const minsUntilOpen = (openHour * 60 + openMinute) - (hour * 60 + minute);
  return minsUntilOpen > 0 && minsUntilOpen <= withinMinutes;
}

module.exports = { isOrderingOpen, isOrderingOpeningSoon, getWindowDescription, getWarsawNow, getOrderingWindowOpenAt, getOrderingWindowCloseAt, getPreviousOrderingCloseAt, getOpenDateWarsaw, DAY_SHORT_UK, DAY_FULL_UK };
